import { Router } from "express";
import type { Request, Response, NextFunction } from "express";
import { z } from "zod";
import { validate } from "../middleware/validate.js";
import { authenticate } from "../middleware/auth.js";
import {
  createStoreToken,
  deleteStoreToken,
  listStoreTokens,
  revokeStoreToken,
  updateStoreToken,
  validateStoreToken,
} from "../services/store.service.js";

const router = Router();

const createSchema = z.object({
  storeName: z.string().min(1).max(100),
  storeUrl: z.string().url("Must be a valid URL"),
  storeType: z.string().min(1),
  scopes: z.array(z.string()).min(1, "At least one scope is required"),
  webhookUrl: z
    .string()
    .url("webhookUrl must be a valid URL")
    .optional()
    .or(z.literal("")),
  expiresInDays: z.number().positive().optional(),
});

router.post(
  "/",
  authenticate,
  validate(createSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const {
        storeName,
        storeUrl,
        storeType,
        scopes,
        webhookUrl,
        expiresInDays,
      } = req.body;
      const token = await createStoreToken(
        req.user!.userId,
        storeName,
        storeUrl,
        storeType,
        scopes,
        webhookUrl || undefined,
        expiresInDays
      );
      res.status(201).json({
        ...token,
        message:
          "Store this token securely — it won't be shown in full again.",
      });
    } catch (err) {
      next(err);
    }
  }
);

router.get(
  "/",
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tokens = await listStoreTokens(req.user!.userId);
      res.json(tokens);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/:id/revoke",
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await revokeStoreToken(req.user!.userId, req.params.id as string);
      res.json({ message: "Store token revoked" });
    } catch (err) {
      next(err);
    }
  }
);

const updateSchema = z.object({
  storeName: z.string().min(1).max(100).optional(),
  storeUrl: z.string().url("Must be a valid URL").optional(),
  scopes: z.array(z.string()).min(1).optional(),
  webhookUrl: z
    .string()
    .url("webhookUrl must be a valid URL")
    .nullable()
    .optional()
    .or(z.literal("")),
  expiresInDays: z.number().positive().nullable().optional(),
});

router.patch(
  "/:id",
  authenticate,
  validate(updateSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { storeName, storeUrl, scopes, webhookUrl, expiresInDays } =
        req.body as z.infer<typeof updateSchema>;

      const input: Parameters<typeof updateStoreToken>[2] = {};
      if (storeName !== undefined) input.storeName = storeName;
      if (storeUrl !== undefined) input.storeUrl = storeUrl;
      if (scopes !== undefined) input.scopes = scopes;
      if (webhookUrl !== undefined) {
        // empty string is treated as "clear the webhook"
        input.webhookUrl = webhookUrl === "" ? null : webhookUrl;
      }
      if (expiresInDays !== undefined) {
        input.expiresAt =
          expiresInDays === null
            ? null
            : new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000);
      }

      const updated = await updateStoreToken(
        req.user!.userId,
        req.params.id as string,
        input
      );
      res.json(updated);
    } catch (err) {
      next(err);
    }
  }
);

router.delete(
  "/:id",
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await deleteStoreToken(req.user!.userId, req.params.id as string);
      res.json({ message: "Store token deleted" });
    } catch (err) {
      next(err);
    }
  }
);

const validateSchema = z.object({
  token: z.string(),
});

router.post(
  "/validate",
  validate(validateSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await validateStoreToken(req.body.token);
      if (!result.valid) {
        return res.status(401).json(result);
      }
      res.json(result);
    } catch (err) {
      next(err);
    }
  }
);

export default router;
