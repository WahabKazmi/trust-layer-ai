import { Router } from "express";
import type { Request, Response, NextFunction } from "express";
import passport from "passport";
import { signAccessToken, signRefreshToken } from "../utils/jwt.js";
import { generateSecureToken } from "../utils/crypto.js";
import prisma from "../config/db.js";
import { env } from "../config/env.js";

const router = Router();

interface OAuthUser {
  id: string;
  email: string;
  role: string;
}

async function issueTokensAndRedirect(user: OAuthUser, res: Response) {
  const accessToken = signAccessToken({
    userId: user.id,
    email: user.email,
    role: user.role,
  });

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);

  const placeholder = generateSecureToken();
  const record = await prisma.refreshToken.create({
    data: { token: placeholder, userId: user.id, expiresAt },
  });

  const refreshToken = signRefreshToken({
    userId: user.id,
    tokenId: record.id,
  });

  await prisma.refreshToken.update({
    where: { id: record.id },
    data: { token: refreshToken },
  });

  const params = new URLSearchParams({
    accessToken,
    refreshToken,
  });

  res.redirect(`${env.CLIENT_URL}/auth/callback?${params.toString()}`);
}

// Google
router.get(
  "/google",
  passport.authenticate("google", { scope: ["profile", "email"], session: false })
);

router.get(
  "/google/callback",
  passport.authenticate("google", { session: false, failureRedirect: "/auth/login" }),
  async (req: Request, res: Response, _next: NextFunction) => {
    const user = req.user as OAuthUser;
    await issueTokensAndRedirect(user, res);
  }
);

// GitHub
router.get(
  "/github",
  passport.authenticate("github", { scope: ["user:email"], session: false })
);

router.get(
  "/github/callback",
  passport.authenticate("github", { session: false, failureRedirect: "/auth/login" }),
  async (req: Request, res: Response, _next: NextFunction) => {
    const user = req.user as OAuthUser;
    await issueTokensAndRedirect(user, res);
  }
);

export default router;
