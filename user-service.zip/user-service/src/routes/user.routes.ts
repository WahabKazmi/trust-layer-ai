import { Router } from "express";
import type { Request, Response, NextFunction } from "express";
import { z } from "zod";
import { validate } from "../middleware/validate.js";
import { authenticate } from "../middleware/auth.js";
import { requireRole } from "../middleware/rbac.js";
import {
  getUserById,
  updateUser,
  deleteUser,
  listUsers,
  changeUserRole,
} from "../services/user.service.js";

const router = Router();

router.use(authenticate);

router.get(
  "/me",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await getUserById(req.user!.userId);
      res.json(user);
    } catch (err) {
      next(err);
    }
  }
);

const updateSchema = z.object({
  name: z.string().optional(),
  email: z.string().email().optional(),
});

router.patch(
  "/me",
  validate(updateSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await updateUser(req.user!.userId, req.body);
      res.json(user);
    } catch (err) {
      next(err);
    }
  }
);

router.delete(
  "/me",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await deleteUser(req.user!.userId);
      res.json({ message: "Account deleted" });
    } catch (err) {
      next(err);
    }
  }
);

router.get(
  "/",
  requireRole("ADMIN"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const result = await listUsers(page, limit);
      res.json(result);
    } catch (err) {
      next(err);
    }
  }
);

const roleSchema = z.object({
  role: z.enum(["USER", "MODERATOR", "ADMIN"]),
});

router.patch(
  "/:id/role",
  requireRole("ADMIN"),
  validate(roleSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await changeUserRole(req.params.id as string, req.body.role);
      res.json(user);
    } catch (err) {
      next(err);
    }
  }
);

export default router;
