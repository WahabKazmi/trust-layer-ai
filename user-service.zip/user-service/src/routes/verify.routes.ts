import { Router } from "express";
import type { Request, Response, NextFunction } from "express";
import { z } from "zod";
import { validate } from "../middleware/validate.js";
import prisma from "../config/db.js";
import { AppError } from "../middleware/error.js";
import { generateSecureToken } from "../utils/crypto.js";
import { hashPassword } from "../utils/hash.js";
import { sendPasswordResetEmail } from "../services/email.service.js";

const router = Router();

router.get(
  "/verify-email/:token",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const token = req.params.token as string;

      const user = await prisma.user.findFirst({
        where: { verifyToken: token },
      });

      if (!user) {
        throw new AppError(400, "Invalid or expired verification token");
      }

      await prisma.user.update({
        where: { id: user.id },
        data: { emailVerified: true, verifyToken: null },
      });

      res.json({ message: "Email verified successfully" });
    } catch (err) {
      next(err);
    }
  }
);

const forgotPasswordSchema = z.object({
  email: z.string().email(),
});

router.post(
  "/forgot-password",
  validate(forgotPasswordSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email } = req.body;

      const user = await prisma.user.findUnique({ where: { email } });

      // Always return success to prevent email enumeration
      if (!user) {
        return res.json({
          message: "If the email exists, a reset link has been sent",
        });
      }

      const resetToken = generateSecureToken();
      const resetTokenExp = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

      await prisma.user.update({
        where: { id: user.id },
        data: { resetToken, resetTokenExp },
      });

      await sendPasswordResetEmail(email, resetToken);

      res.json({
        message: "If the email exists, a reset link has been sent",
      });
    } catch (err) {
      next(err);
    }
  }
);

const resetPasswordSchema = z.object({
  token: z.string(),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

router.post(
  "/reset-password",
  validate(resetPasswordSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { token, password } = req.body;

      const user = await prisma.user.findFirst({
        where: { resetToken: token },
      });

      if (!user || !user.resetTokenExp || user.resetTokenExp < new Date()) {
        throw new AppError(400, "Invalid or expired reset token");
      }

      const hashed = await hashPassword(password);

      await prisma.user.update({
        where: { id: user.id },
        data: {
          password: hashed,
          resetToken: null,
          resetTokenExp: null,
        },
      });

      res.json({ message: "Password reset successfully" });
    } catch (err) {
      next(err);
    }
  }
);

export default router;
