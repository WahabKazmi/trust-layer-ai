import { Router } from "express";
import type { Request, Response, NextFunction } from "express";
import { z } from "zod";
import { validate } from "../middleware/validate.js";
import {
  registerUser,
  loginUser,
  refreshAccessToken,
  logoutUser,
} from "../services/auth.service.js";

const router = Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8, "Password must be at least 8 characters"),
  name: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const refreshSchema = z.object({
  refreshToken: z.string(),
});

router.post(
  "/register",
  validate(registerSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password, name } = req.body;
      const result = await registerUser(email, password, name);
      res
        .status(201)
        .json({ message: "Registration successful. Check your email to verify.", user: result });
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/login",
  validate(loginSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password } = req.body;
      const tokens = await loginUser(email, password);
      res.json(tokens);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/refresh",
  validate(refreshSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { refreshToken } = req.body;
      const tokens = await refreshAccessToken(refreshToken);
      res.json(tokens);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/logout",
  validate(refreshSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { refreshToken } = req.body;
      await logoutUser(refreshToken);
      res.json({ message: "Logged out successfully" });
    } catch (err) {
      next(err);
    }
  }
);

export default router;
