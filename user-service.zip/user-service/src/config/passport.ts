import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as GitHubStrategy } from "passport-github2";
import { env } from "./env.js";
import prisma from "./db.js";

function isOAuthConfigured(clientId: string, clientSecret: string): boolean {
  return clientId.length > 0 && clientSecret.length > 0;
}

if (isOAuthConfigured(env.GOOGLE_CLIENT_ID, env.GOOGLE_CLIENT_SECRET)) {
  passport.use(
    new GoogleStrategy(
      {
        clientID: env.GOOGLE_CLIENT_ID,
        clientSecret: env.GOOGLE_CLIENT_SECRET,
        callbackURL: env.GOOGLE_CALLBACK_URL,
      },
      async (_accessToken, _refreshToken, profile, done) => {
        try {
          const email = profile.emails?.[0]?.value;
          if (!email) {
            return done(new Error("No email found in Google profile"));
          }

          let user = await prisma.user.findFirst({
            where: { oauthProvider: "google", oauthId: profile.id },
          });

          if (!user) {
            user = await prisma.user.findUnique({ where: { email } });

            if (user) {
              user = await prisma.user.update({
                where: { id: user.id },
                data: {
                  oauthProvider: "google",
                  oauthId: profile.id,
                  emailVerified: true,
                },
              });
            } else {
              user = await prisma.user.create({
                data: {
                  email,
                  name: profile.displayName,
                  oauthProvider: "google",
                  oauthId: profile.id,
                  emailVerified: true,
                },
              });
            }
          }

          done(null, user as any);
        } catch (err) {
          done(err as Error);
        }
      }
    )
  );
}

if (isOAuthConfigured(env.GITHUB_CLIENT_ID, env.GITHUB_CLIENT_SECRET)) {
  passport.use(
    new GitHubStrategy(
      {
        clientID: env.GITHUB_CLIENT_ID,
        clientSecret: env.GITHUB_CLIENT_SECRET,
        callbackURL: env.GITHUB_CALLBACK_URL,
      },
      async (
        _accessToken: string,
        _refreshToken: string,
        profile: any,
        done: any
      ) => {
        try {
          const email =
            profile.emails?.[0]?.value ??
            `${profile.id}@github.noreply.com`;

          let user = await prisma.user.findFirst({
            where: { oauthProvider: "github", oauthId: profile.id },
          });

          if (!user) {
            user = await prisma.user.findUnique({ where: { email } });

            if (user) {
              user = await prisma.user.update({
                where: { id: user.id },
                data: {
                  oauthProvider: "github",
                  oauthId: profile.id,
                  emailVerified: true,
                },
              });
            } else {
              user = await prisma.user.create({
                data: {
                  email,
                  name: profile.displayName ?? profile.username ?? null,
                  oauthProvider: "github",
                  oauthId: profile.id,
                  emailVerified: true,
                },
              });
            }
          }

          done(null, user);
        } catch (err) {
          done(err as Error);
        }
      }
    )
  );
}
