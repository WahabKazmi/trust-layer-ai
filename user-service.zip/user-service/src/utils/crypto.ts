import { randomBytes } from "crypto";

export function generateSecureToken(bytes = 32): string {
  return randomBytes(bytes).toString("hex");
}

export function generateApiKey(): string {
  const prefix = "nk";
  const key = randomBytes(24).toString("base64url");
  return `${prefix}_${key}`;
}
