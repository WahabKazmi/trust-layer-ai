declare global {
  namespace Express {
    interface User {
      userId: string;
      email: string;
      role: string;
      id: string;
    }
  }
}

export interface AuthPayload {
  userId: string;
  email: string;
  role: string;
}
