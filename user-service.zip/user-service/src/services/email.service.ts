import nodemailer from "nodemailer";
import { env } from "../config/env.js";

const smtpConfigured = !!(env.SMTP_USER && env.SMTP_PASS);

const transporter = smtpConfigured
  ? nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      secure: env.SMTP_PORT === 465,
      auth: { user: env.SMTP_USER, pass: env.SMTP_PASS },
    })
  : null;

export async function sendVerificationEmail(
  email: string,
  token: string
): Promise<void> {
  const verifyUrl = `${env.CLIENT_URL}/auth/verify-email?token=${token}`;

  if (!transporter) {
    console.log(`[DEV] Verification email for ${email}:`);
    console.log(`[DEV] ${verifyUrl}`);
    return;
  }

  await transporter.sendMail({
    from: env.EMAIL_FROM,
    to: email,
    subject: "Verify your email",
    html: `
      <h2>Welcome!</h2>
      <p>Click the link below to verify your email address:</p>
      <a href="${verifyUrl}">${verifyUrl}</a>
      <p>If you didn't create an account, you can ignore this email.</p>
    `,
  });
}

export async function sendPasswordResetEmail(
  email: string,
  token: string
): Promise<void> {
  const resetUrl = `${env.CLIENT_URL}/auth/reset-password?token=${token}`;

  if (!transporter) {
    console.log(`[DEV] Password reset email for ${email}:`);
    console.log(`[DEV] ${resetUrl}`);
    return;
  }

  await transporter.sendMail({
    from: env.EMAIL_FROM,
    to: email,
    subject: "Reset your password",
    html: `
      <h2>Password Reset</h2>
      <p>Click the link below to reset your password. This link expires in 1 hour.</p>
      <a href="${resetUrl}">${resetUrl}</a>
      <p>If you didn't request this, you can ignore this email.</p>
    `,
  });
}
