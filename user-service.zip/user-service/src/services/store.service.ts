import prisma from "../config/db.js";
import { generateSecureToken } from "../utils/crypto.js";
import { AppError } from "../middleware/error.js";

const VALID_SCOPES = ["toxicity", "nsfw", "customer-care", "moderate"] as const;
const VALID_STORE_TYPES = ["woocommerce", "shopify", "api"] as const;

export async function createStoreToken(
  userId: string,
  storeName: string,
  storeUrl: string,
  storeType: string,
  scopes: string[],
  webhookUrl?: string,
  expiresInDays?: number
) {
  if (!VALID_STORE_TYPES.includes(storeType as (typeof VALID_STORE_TYPES)[number])) {
    throw new AppError(400, `Unsupported store type: ${storeType}`);
  }

  const invalid = scopes.filter(
    (s) => !VALID_SCOPES.includes(s as (typeof VALID_SCOPES)[number])
  );
  if (invalid.length > 0) {
    throw new AppError(400, `Invalid scopes: ${invalid.join(", ")}`);
  }

  // The "api" platform routes everything through the async /moderate endpoint,
  // so an api token without the `moderate` scope is unusable. Force it in
  // (de-duplicated) so a token created through the dashboard always works
  // end-to-end, regardless of what the user ticked in the scopes selector.
  let effectiveScopes = scopes;
  if (storeType === "api" && !scopes.includes("moderate")) {
    effectiveScopes = [...scopes, "moderate"];
  }

  // Webhook URL is mandatory for the "api" platform: that's how we deliver
  // moderation results back to the consumer. Other platforms (Shopify,
  // WooCommerce, …) get their integration through their own plugins.
  if (storeType === "api" && !webhookUrl) {
    throw new AppError(
      400,
      "webhookUrl is required for API tokens"
    );
  }

  if (webhookUrl) {
    try {
      const u = new URL(webhookUrl);
      if (u.protocol !== "http:" && u.protocol !== "https:") {
        throw new Error("bad protocol");
      }
    } catch {
      throw new AppError(400, "webhookUrl must be a valid http(s) URL");
    }
  }

  const token = generateSecureToken(48);

  const expiresAt = expiresInDays
    ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
    : null;

  const storeToken = await prisma.storeToken.create({
    data: {
      token,
      storeName,
      storeUrl,
      storeType,
      scopes: effectiveScopes,
      webhookUrl: webhookUrl ?? null,
      userId,
      expiresAt,
    },
  });

  return {
    id: storeToken.id,
    token: storeToken.token,
    storeName: storeToken.storeName,
    storeUrl: storeToken.storeUrl,
    storeType: storeToken.storeType,
    scopes: storeToken.scopes,
    webhookUrl: storeToken.webhookUrl,
    expiresAt: storeToken.expiresAt,
    createdAt: storeToken.createdAt,
  };
}

export async function listStoreTokens(userId: string) {
  return prisma.storeToken.findMany({
    where: { userId },
    select: {
      id: true,
      storeName: true,
      storeUrl: true,
      storeType: true,
      scopes: true,
      webhookUrl: true,
      expiresAt: true,
      revoked: true,
      createdAt: true,
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function revokeStoreToken(userId: string, tokenId: string) {
  const storeToken = await prisma.storeToken.findUnique({
    where: { id: tokenId },
  });

  if (!storeToken || storeToken.userId !== userId) {
    throw new AppError(404, "Store token not found");
  }

  await prisma.storeToken.update({
    where: { id: tokenId },
    data: { revoked: true },
  });
}

export interface UpdateStoreTokenInput {
  storeName?: string;
  storeUrl?: string;
  scopes?: string[];
  webhookUrl?: string | null;
  expiresAt?: Date | null;
}

/**
 * Updates the mutable fields of a store token. The secret value (`token`) and
 * `storeType` are intentionally immutable — those define the integration
 * shape and rotating them would break consumers silently.
 */
export async function updateStoreToken(
  userId: string,
  tokenId: string,
  input: UpdateStoreTokenInput
) {
  const existing = await prisma.storeToken.findUnique({
    where: { id: tokenId },
  });

  if (!existing || existing.userId !== userId) {
    throw new AppError(404, "Store token not found");
  }

  if (input.scopes !== undefined) {
    if (input.scopes.length === 0) {
      throw new AppError(400, "At least one scope is required");
    }
    const invalid = input.scopes.filter(
      (s) => !VALID_SCOPES.includes(s as (typeof VALID_SCOPES)[number])
    );
    if (invalid.length > 0) {
      throw new AppError(400, `Invalid scopes: ${invalid.join(", ")}`);
    }
  }

  if (input.webhookUrl) {
    try {
      const u = new URL(input.webhookUrl);
      if (u.protocol !== "http:" && u.protocol !== "https:") {
        throw new Error("bad protocol");
      }
    } catch {
      throw new AppError(400, "webhookUrl must be a valid http(s) URL");
    }
  }

  // For API tokens, `moderate` is the only scope that does anything (it's the
  // gate on the async /moderate endpoint), so we re-add it on update if the
  // user accidentally removed it. Same idea as on create: an API token must
  // always be usable for the async webhook flow.
  let nextScopes = input.scopes ?? existing.scopes;
  if (
    existing.storeType === "api" &&
    input.scopes !== undefined &&
    !nextScopes.includes("moderate")
  ) {
    nextScopes = [...nextScopes, "moderate"];
  }

  // For API tokens, a webhookUrl must remain set — without it the worker has
  // nowhere to deliver the result.
  const nextWebhook =
    input.webhookUrl === undefined ? existing.webhookUrl : input.webhookUrl;
  if (existing.storeType === "api" && !nextWebhook) {
    throw new AppError(
      400,
      "webhookUrl is required for API tokens"
    );
  }

  const data: Record<string, unknown> = {};
  if (input.storeName !== undefined) data.storeName = input.storeName;
  if (input.storeUrl !== undefined) data.storeUrl = input.storeUrl;
  if (input.scopes !== undefined) data.scopes = nextScopes;
  if (input.webhookUrl !== undefined)
    data.webhookUrl = input.webhookUrl ?? null;
  if (input.expiresAt !== undefined) data.expiresAt = input.expiresAt;

  const updated = await prisma.storeToken.update({
    where: { id: tokenId },
    data,
    select: {
      id: true,
      storeName: true,
      storeUrl: true,
      storeType: true,
      scopes: true,
      webhookUrl: true,
      expiresAt: true,
      revoked: true,
      createdAt: true,
    },
  });

  return updated;
}

/**
 * Hard-deletes a store token. The token's secret can no longer validate after
 * this — prefer `revokeStoreToken` if you only want to invalidate it but keep
 * an audit trail.
 */
export async function deleteStoreToken(userId: string, tokenId: string) {
  const existing = await prisma.storeToken.findUnique({
    where: { id: tokenId },
  });

  if (!existing || existing.userId !== userId) {
    throw new AppError(404, "Store token not found");
  }

  await prisma.storeToken.delete({ where: { id: tokenId } });
}

export async function validateStoreToken(token: string) {
  const storeToken = await prisma.storeToken.findUnique({
    where: { token },
  });

  if (!storeToken) {
    return { valid: false, error: "Token not found" };
  }

  if (storeToken.revoked) {
    return { valid: false, error: "Token has been revoked" };
  }

  if (storeToken.expiresAt && storeToken.expiresAt < new Date()) {
    return { valid: false, error: "Token has expired" };
  }

  return {
    valid: true,
    userId: storeToken.userId,
    storeName: storeToken.storeName,
    storeUrl: storeToken.storeUrl,
    storeType: storeToken.storeType,
    scopes: storeToken.scopes,
    webhookUrl: storeToken.webhookUrl,
  };
}
