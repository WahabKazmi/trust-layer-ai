import prisma from "../config/db.js";
import { AppError } from "../middleware/error.js";

const userSelect = {
  id: true,
  email: true,
  name: true,
  role: true,
  emailVerified: true,
  oauthProvider: true,
  createdAt: true,
  updatedAt: true,
} as const;

export async function getUserById(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: userSelect,
  });

  if (!user) throw new AppError(404, "User not found");
  return user;
}

export async function updateUser(
  userId: string,
  data: { name?: string; email?: string }
) {
  if (data.email) {
    const existing = await prisma.user.findFirst({
      where: { email: data.email, id: { not: userId } },
    });
    if (existing) throw new AppError(409, "Email already in use");
  }

  return prisma.user.update({
    where: { id: userId },
    data,
    select: userSelect,
  });
}

export async function deleteUser(userId: string) {
  await prisma.refreshToken.deleteMany({ where: { userId } });
  await prisma.storeToken.deleteMany({ where: { userId } });
  await prisma.user.delete({ where: { id: userId } });
}

export async function listUsers(page = 1, limit = 20) {
  const skip = (page - 1) * limit;

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      select: userSelect,
      skip,
      take: limit,
      orderBy: { createdAt: "desc" },
    }),
    prisma.user.count(),
  ]);

  return { users, total, page, limit };
}

export async function changeUserRole(
  userId: string,
  role: "USER" | "MODERATOR" | "ADMIN"
) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) throw new AppError(404, "User not found");

  return prisma.user.update({
    where: { id: userId },
    data: { role },
    select: userSelect,
  });
}
