import prisma from "../config/db.js";
import { hashPassword, comparePassword } from "../utils/hash.js";
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from "../utils/jwt.js";
import { generateSecureToken } from "../utils/crypto.js";
import { AppError } from "../middleware/error.js";
import { sendVerificationEmail } from "./email.service.js";

export async function registerUser(
  email: string,
  password: string,
  name?: string
) {
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    throw new AppError(409, "Email already registered");
  }

  const hashed = await hashPassword(password);
  const verifyToken = generateSecureToken();

  const autoVerify = !process.env.SMTP_USER || !process.env.SMTP_PASS;

  const user = await prisma.user.create({
    data: {
      email,
      password: hashed,
      name: name ?? null,
      verifyToken,
      emailVerified: autoVerify,
    },
  });

  await sendVerificationEmail(email, verifyToken);

  return { id: user.id, email: user.email };
}

export async function loginUser(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !user.password) {
    throw new AppError(401, "Invalid credentials");
  }

  const valid = await comparePassword(password, user.password);
  if (!valid) {
    throw new AppError(401, "Invalid credentials");
  }

  if (!user.emailVerified) {
    throw new AppError(403, "Please verify your email before logging in");
  }

  return issueTokens(user.id, user.email, user.role);
}

export async function refreshAccessToken(refreshToken: string) {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw new AppError(401, "Invalid or expired refresh token");
  }

  const stored = await prisma.refreshToken.findUnique({
    where: { id: payload.tokenId },
    include: { user: true },
  });

  if (!stored || stored.token !== refreshToken) {
    throw new AppError(401, "Refresh token not found or revoked");
  }

  if (stored.expiresAt < new Date()) {
    await prisma.refreshToken.delete({ where: { id: stored.id } });
    throw new AppError(401, "Refresh token expired");
  }

  await prisma.refreshToken.delete({ where: { id: stored.id } });

  return issueTokens(stored.user.id, stored.user.email, stored.user.role);
}

export async function logoutUser(refreshToken: string) {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    return;
  }

  await prisma.refreshToken
    .delete({ where: { id: payload.tokenId } })
    .catch(() => {});
}

async function issueTokens(userId: string, email: string, role: string) {
  const accessToken = signAccessToken({ userId, email, role });

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);

  const tokenPlaceholder = generateSecureToken();
  const record = await prisma.refreshToken.create({
    data: {
      token: tokenPlaceholder,
      userId,
      expiresAt,
    },
  });

  const refreshToken = signRefreshToken({
    userId,
    tokenId: record.id,
  });

  await prisma.refreshToken.update({
    where: { id: record.id },
    data: { token: refreshToken },
  });

  return { accessToken, refreshToken };
}
