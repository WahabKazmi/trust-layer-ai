import { env } from "./config/env.js";
import app from "./app.js";
import prisma from "./config/db.js";

async function main() {
  await prisma.$connect();
  console.log("Connected to MongoDB");

  app.listen(env.PORT, () => {
    console.log(`User service running on port ${env.PORT}`);
  });
}

main().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
