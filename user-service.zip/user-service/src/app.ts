import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import passport from "passport";
import { env } from "./config/env.js";
import authRoutes from "./routes/auth.routes.js";
import oauthRoutes from "./routes/oauth.routes.js";
import verifyRoutes from "./routes/verify.routes.js";
import userRoutes from "./routes/user.routes.js";
import storeRoutes from "./routes/store.routes.js";
import { errorHandler } from "./middleware/error.js";
import "./config/passport.js";

const app = express();

app.use(cors({ origin: env.CLIENT_URL, credentials: true }));
app.use(express.json());
app.use(cookieParser());
app.use(passport.initialize());

app.get("/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.use("/auth", authRoutes);
app.use("/auth", oauthRoutes);
app.use("/auth", verifyRoutes);
app.use("/users", userRoutes);
app.use("/store-tokens", storeRoutes);

app.use(errorHandler);

export default app;
