# POC Store — Trust Layer demo

A minimal e-commerce page that uses the Trust Layer API + webhooks to moderate
product reviews. It is deliberately tiny: one product, an in-memory review
list, and a single HTML file for the UI.

## Flow

```
 ┌─────────────────────┐                       ┌──────────────────────┐
 │  POC Store (this)   │  POST /moderate       │ neucleas-ai          │
 │  http://:6001       │─────────────────────▶ │ (validates token via │
 │                     │  Bearer ACCESS_TOKEN  │  user-service and    │
 │                     │  body: { text }       │  reads webhookUrl    │
 │                     │◀──── 202 jobId ────── │  from the token)     │
 │  reviews[]          │                       │                      │
 │  status: pending    │                       │   ↓ enqueues         │
 │                     │                       │   BullMQ worker runs │
 │  POST /api/webhook/ │                       │   isToxic + reply    │
 │   moderation        │◀────── webhook ────── │                      │
 │  (updates review)   │                       │                      │
 │       │             │                       └──────────────────────┘
 │       └─SSE push──▶ browser
 └─────────────────────┘
```

The two big differences from a typical "send a webhook URL on every request"
integration:

1. **Webhook URL lives on the access token.** Configure it once on the Trust
   Layer dashboard and you never send `webhookUrl` in your request body again.
   Just `Authorization: Bearer <token>` + `{ text }`.
2. **No polling anywhere.** When the AI worker finishes, it POSTs the result
   to the webhook URL you configured. Our server then fans that update out to
   the browser via Server-Sent Events. The UI updates the moment the verdict
   arrives.

## Setup

1. In the Trust Layer dashboard (`http://localhost:3000`), go to **Store
   Tokens → Create Token** and pick:
   - **Platform**: `Custom API (any platform)`
   - **Scopes**: at least `moderate`
   - **Webhook URL**: `http://localhost:6001/api/webhook/moderation`
     (in production, point this at your public URL — e.g. an ngrok tunnel.)
2. Copy the access token and put it into `poc-store/.env`:
   ```
   ACCESS_TOKEN=<your-token>
   ```
3. Install + run:
   ```
   npm install
   npm run dev
   ```
4. Open `http://localhost:6001`, post a review, watch it move from
   `Awaiting AI` → `Approved` (or `Flagged`) in real time — no refresh, no
   polling.

> Browsers (Chrome / Firefox / Safari) block port `6000` as an unsafe port
> (X11), which is why this app defaults to `6001`. Override with `PORT=…` in
> `.env` if you prefer something else — just steer clear of the
> [restricted port list](https://chromium.googlesource.com/chromium/src/+/refs/heads/main/net/base/port_util.cc).

## What you have to do as an API consumer

That's the whole integration:

```http
POST /moderate
Authorization: Bearer <your access token>
Content-Type: application/json

{ "text": "the user-generated content", "metadata": { "reviewId": "..." } }
```

Then expose **one** endpoint that accepts the webhook payload:

```json
{
  "jobId": "1",
  "status": "done",
  "result": { "toxic": false, "score": 0.012, "reply": "Thanks for…" },
  "metadata": { "reviewId": "..." }
}
```

No status calls, no retries, no polling.

## Required services

This store calls the Trust Layer AI service which in turn validates tokens
against the user-service:

- `user-service` on `:4000`
- `neucleas-ai` API on `:5000`
- `neucleas-ai` worker (BullMQ + Redis on `:6379`)

The simplest way to start everything together is the repo-root
`./start.sh` script.
