#!/usr/bin/env node
/**
 * One-shot helper: log in to user-service, create a Trust Layer API token
 * with the `moderate` scope + webhook URL, and write it into poc-store/.env.
 *
 * Usage:
 *   node setup-token.mjs                       # prompts for email + password
 *   node setup-token.mjs you@x.com 'pa$$w0rd'  # non-interactive
 *
 * Env overrides (optional):
 *   USER_SERVICE_URL  default http://localhost:4000
 *   PORT              default 6001            (used to build the webhook URL)
 *   WEBHOOK_URL       default http://localhost:${PORT}/api/webhook/moderation
 *   STORE_NAME        default "POC Store"
 *   STORE_URL         default http://localhost:${PORT}
 */
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ENV_PATH = path.join(__dirname, ".env");

const USER_SERVICE_URL =
  process.env.USER_SERVICE_URL || "http://localhost:4000";
const PORT = parseInt(process.env.PORT || "6001", 10);
const STORE_URL = process.env.STORE_URL || `http://localhost:${PORT}`;
const WEBHOOK_URL =
  process.env.WEBHOOK_URL || `${STORE_URL}/api/webhook/moderation`;
const STORE_NAME = process.env.STORE_NAME || "POC Store";

function prompt(question, { silent = false } = {}) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: true,
    });
    if (silent) {
      // hide password input
      const stdin = process.openStdin();
      process.stdout.write(question);
      let value = "";
      const onData = (char) => {
        const s = char.toString("utf8");
        if (s === "\n" || s === "\r" || s === "\u0004") {
          stdin.removeListener("data", onData);
          process.stdout.write("\n");
          rl.close();
          resolve(value);
          return;
        }
        if (s === "\u0003") process.exit(1);
        value += s;
      };
      stdin.on("data", onData);
    } else {
      rl.question(question, (answer) => {
        rl.close();
        resolve(answer.trim());
      });
    }
  });
}

async function main() {
  let [email, password] = process.argv.slice(2);
  if (!email) email = await prompt("Dashboard email: ");
  if (!password) password = await prompt("Dashboard password: ", { silent: true });

  if (!email || !password) {
    console.error("Email and password are required.");
    process.exit(1);
  }

  console.log(`\n→ logging in to ${USER_SERVICE_URL}…`);
  const loginRes = await fetch(`${USER_SERVICE_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const loginBody = await loginRes.json().catch(() => ({}));
  if (!loginRes.ok) {
    console.error("✗ login failed:", loginBody.error || loginRes.status);
    process.exit(1);
  }
  const accessToken = loginBody.accessToken;
  console.log("✓ logged in");

  console.log(`→ creating API token with webhookUrl=${WEBHOOK_URL}…`);
  const createRes = await fetch(`${USER_SERVICE_URL}/store-tokens`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      storeName: STORE_NAME,
      storeUrl: STORE_URL,
      storeType: "api",
      scopes: ["moderate"],
      webhookUrl: WEBHOOK_URL,
    }),
  });
  const createBody = await createRes.json().catch(() => ({}));
  if (!createRes.ok) {
    console.error("✗ token creation failed:", createBody.error || createRes.status);
    process.exit(1);
  }
  const token = createBody.token;
  if (!token) {
    console.error("✗ user-service did not return a token:", createBody);
    process.exit(1);
  }
  console.log("✓ token created:", token.slice(0, 12) + "…");

  // Update poc-store/.env in place: replace ACCESS_TOKEN line, or append it.
  let envText = "";
  try {
    envText = fs.readFileSync(ENV_PATH, "utf8");
  } catch {
    envText = "";
  }

  const line = `ACCESS_TOKEN=${token}`;
  if (/^ACCESS_TOKEN=.*$/m.test(envText)) {
    envText = envText.replace(/^ACCESS_TOKEN=.*$/m, line);
  } else {
    if (envText && !envText.endsWith("\n")) envText += "\n";
    envText += line + "\n";
  }
  fs.writeFileSync(ENV_PATH, envText, "utf8");
  console.log(`✓ wrote ACCESS_TOKEN to ${ENV_PATH}`);

  console.log("\nAll set. Restart the POC store to pick up the new token:");
  console.log("  npm run dev\n");
}

main().catch((err) => {
  console.error("✗", err.message);
  process.exit(1);
});
