import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { randomUUID } from "crypto";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = parseInt(process.env.PORT || "6001", 10);
const AI_API_URL = process.env.AI_API_URL || "http://localhost:5000";
const ACCESS_TOKEN = process.env.ACCESS_TOKEN || "";

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const product = {
  id: "prod_001",
  name: "Aurora Wireless Headphones",
  price: 149.0,
  currency: "USD",
  image:
    "https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?w=800&q=80",
  description:
    "Studio-grade 40 mm drivers, 50 hours of battery life, and adaptive noise cancellation that keeps you in the zone.",
};

/**
 * In-memory review store.
 * Each review:
 *   {
 *     id, author, text, createdAt,
 *     status: "pending" | "approved" | "flagged" | "error",
 *     score: number | null,
 *     aiReply: string | null,
 *     jobId: string | null,
 *     error: string | null
 *   }
 */
const reviews = [
  {
    id: randomUUID(),
    author: "Mira",
    text: "Absolutely love the sound quality, beats my old pair by miles.",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    status: "approved",
    score: 0.01,
    aiReply:
      "Thank you so much for the kind words, Mira! We're thrilled the Aurora is exceeding your expectations. — XYZ Store Customer Care",
    jobId: null,
    error: null,
  },
];

function publicReview(r) {
  return {
    id: r.id,
    author: r.author,
    text: r.text,
    createdAt: r.createdAt,
    status: r.status,
    score: r.score,
    aiReply: r.aiReply,
    error: r.error,
  };
}

// ---------------------------------------------------------------------------
// Server-Sent Events: the moment the Trust Layer webhook lands, push the
// updated review straight to every connected browser. No polling.
// ---------------------------------------------------------------------------
const sseClients = new Set();

function broadcast(event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) {
    res.write(payload);
  }
}

app.get("/api/reviews/stream", (req, res) => {
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });
  res.flushHeaders?.();
  res.write(`event: hello\ndata: {"ok":true}\n\n`);

  sseClients.add(res);

  const keepalive = setInterval(() => {
    res.write(": ping\n\n");
  }, 25000);

  req.on("close", () => {
    clearInterval(keepalive);
    sseClients.delete(res);
  });
});

app.get("/api/product", (_req, res) => {
  res.json(product);
});

app.get("/api/config", (_req, res) => {
  res.json({
    aiApiUrl: AI_API_URL,
    accessTokenConfigured: Boolean(ACCESS_TOKEN),
  });
});

app.get("/api/reviews", (_req, res) => {
  const sorted = [...reviews].sort((a, b) =>
    a.createdAt < b.createdAt ? 1 : -1
  );
  res.json(sorted.map(publicReview));
});

app.post("/api/reviews", async (req, res) => {
  const { author, text } = req.body || {};
  if (!author || !text) {
    return res.status(400).json({ error: "author and text are required" });
  }
  if (!ACCESS_TOKEN) {
    return res.status(500).json({
      error:
        "ACCESS_TOKEN is not configured on the POC store. Create one in the Trust Layer dashboard and put it in poc-store/.env",
    });
  }

  const review = {
    id: randomUUID(),
    author: String(author).slice(0, 60),
    text: String(text).slice(0, 1000),
    createdAt: new Date().toISOString(),
    status: "pending",
    score: null,
    aiReply: null,
    jobId: null,
    error: null,
  };
  reviews.push(review);

  try {
    // Note: we no longer pass `webhookUrl`. With an "api" Trust Layer token
    // the webhook URL is configured once on the dashboard and lives on the
    // token itself. We just send the text + a metadata hint so the webhook
    // payload can tell us which review it belongs to.
    const response = await fetch(`${AI_API_URL}/moderate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ACCESS_TOKEN}`,
      },
      body: JSON.stringify({
        text: review.text,
        metadata: { reviewId: review.id, productId: product.id },
      }),
    });

    const body = await response.json().catch(() => ({}));

    if (!response.ok) {
      review.status = "error";
      review.error = body.error || `AI service returned ${response.status}`;
      console.error(`[poc-store] /moderate failed:`, review.error);
      broadcast("review.updated", publicReview(review));
      return res.status(502).json({
        error: "Failed to enqueue moderation job",
        detail: review.error,
        review: publicReview(review),
      });
    }

    review.jobId = body.jobId || null;
    broadcast("review.created", publicReview(review));
    res.status(202).json({ review: publicReview(review), jobId: review.jobId });
  } catch (err) {
    review.status = "error";
    review.error = err.message;
    console.error(`[poc-store] /moderate threw:`, err.message);
    broadcast("review.updated", publicReview(review));
    res.status(502).json({
      error: "Could not reach AI service",
      detail: err.message,
      review: publicReview(review),
    });
  }
});

// Single webhook endpoint — the URL we put on the Trust Layer dashboard for
// this store's API token. The reviewId arrives in `metadata`, not in the URL.
app.post("/api/webhook/moderation", (req, res) => {
  const { result, status, metadata } = req.body || {};
  const reviewId = metadata?.reviewId;
  const review = reviewId ? reviews.find((r) => r.id === reviewId) : null;

  if (!review) {
    console.warn(
      `[poc-store] webhook: unknown reviewId in metadata`,
      metadata
    );
    return res.status(404).json({ error: "review not found" });
  }

  if (status !== "done" || !result) {
    review.status = "error";
    review.error = "Webhook payload missing result";
    broadcast("review.updated", publicReview(review));
    return res.json({ ok: true });
  }

  review.score = typeof result.score === "number" ? result.score : null;
  review.aiReply = result.reply || null;
  review.status = result.toxic ? "flagged" : "approved";
  review.error = null;

  console.log(
    `[poc-store] webhook → review ${review.id} → ${review.status}` +
      (review.score != null ? ` (score=${review.score.toFixed(3)})` : "")
  );

  broadcast("review.updated", publicReview(review));
  res.json({ ok: true });
});

app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => {
  console.log(`POC store running on http://localhost:${PORT}`);
  if (!ACCESS_TOKEN) {
    console.warn(
      "[poc-store] WARNING: ACCESS_TOKEN is not set — review submissions will fail until you set it in .env"
    );
  }
});
