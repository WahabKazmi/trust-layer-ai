import "dotenv/config";
import { startWorker } from "./src/worker.js";

startWorker();
console.log("Worker started — waiting for jobs...");
