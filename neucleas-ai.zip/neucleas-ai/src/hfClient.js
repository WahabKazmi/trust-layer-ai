import { InferenceClient } from "@huggingface/inference";

if (!process.env.HF_TOKEN) {
  console.error("ERROR: HF_TOKEN is not set in .env");
  process.exit(1);
}

export const hf = new InferenceClient(process.env.HF_TOKEN);
