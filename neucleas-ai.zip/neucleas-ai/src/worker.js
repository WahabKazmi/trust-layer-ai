import { Worker } from "bullmq";
import { isToxic } from "./services/toxicity.js";
import { generateReply } from "./services/customerCare.js";

const REDIS_CONNECTION = {
  host: process.env.REDIS_HOST || "127.0.0.1",
  port: parseInt(process.env.REDIS_PORT || "6379"),
};

async function processModeration(job) {
  const { text, webhookUrl, metadata } = job.data;

  const [toxicity, reply] = await Promise.all([
    isToxic(text),
    generateReply(text),
  ]);

  const result = { ...toxicity, reply };

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jobId: job.id,
      status: "done",
      result,
      metadata: metadata ?? null,
    }),
  });

  if (!response.ok) {
    throw new Error(`Webhook failed with status ${response.status}`);
  }

  return result;
}

export function startWorker() {
  const worker = new Worker("moderation", processModeration, {
    connection: REDIS_CONNECTION,
    concurrency: 3,
  });

  worker.on("completed", (job) => console.log(`Job ${job.id} completed`));
  worker.on("failed", (job, err) => console.error(`Job ${job?.id} failed:`, err.message));

  return worker;
}
