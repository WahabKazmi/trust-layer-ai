import express from "express";
import toxicityRoutes from "./routes/toxicity.js";
import nsfwRoutes from "./routes/nsfw.js";
import customerCareRoutes from "./routes/customerCare.js";
import jobRoutes from "./routes/jobs.js";

const app = express();
app.use(express.json());

app.use(toxicityRoutes);
app.use(nsfwRoutes);
app.use(customerCareRoutes);
app.use(jobRoutes);

app.get("/health", (_req, res) => res.json({ status: "ok" }));

export default app;
