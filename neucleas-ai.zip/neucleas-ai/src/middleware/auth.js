const USER_SERVICE_URL =
  process.env.USER_SERVICE_URL || "http://localhost:4000";

/**
 * Validates a Bearer token by calling user-service's
 * `POST /store-tokens/validate` endpoint and (optionally) requires that the
 * token carry one of the listed scopes.
 *
 * Attaches the validation payload to `req.storeToken`:
 *   { userId, storeName, storeUrl, storeType, scopes, webhookUrl }
 */
export function requireStoreToken(requiredScopes = []) {
  return async (req, res, next) => {
    try {
      const header = req.headers.authorization || "";
      const [scheme, token] = header.split(" ");

      if (scheme !== "Bearer" || !token) {
        return res.status(401).json({
          error: "Missing Authorization: Bearer <access_token> header",
        });
      }

      const response = await fetch(
        `${USER_SERVICE_URL}/store-tokens/validate`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token }),
        }
      );

      const body = await response.json().catch(() => ({}));

      if (!response.ok || !body.valid) {
        return res.status(401).json({
          error: body.error || "Invalid access token",
        });
      }

      if (requiredScopes.length > 0) {
        const granted = new Set(body.scopes || []);
        const missing = requiredScopes.filter((s) => !granted.has(s));
        if (missing.length > 0) {
          return res.status(403).json({
            error: `Token is missing required scope(s): ${missing.join(", ")}`,
          });
        }
      }

      req.storeToken = {
        userId: body.userId,
        storeName: body.storeName,
        storeUrl: body.storeUrl,
        storeType: body.storeType,
        scopes: body.scopes,
        webhookUrl: body.webhookUrl ?? null,
      };

      next();
    } catch (err) {
      console.error("auth middleware error:", err.message);
      res.status(503).json({
        error: "Could not reach auth service to validate token",
      });
    }
  };
}
