import { Router } from "express";
import { isToxic } from "../services/toxicity.js";

const router = Router();

router.post("/check-toxicity", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "Text is required" });

    const result = await isToxic(text);
    res.json(result);
  } catch (err) {
    console.error("check-toxicity error:", err.message);
    res.status(500).json({ error: "Something went wrong" });
  }
});

export default router;
