import { Router } from "express";
import { generateReply } from "../services/customerCare.js";

const router = Router();

router.post("/customer-care", async (req, res) => {
  try {
    const { feedback } = req.body;
    if (!feedback) return res.status(400).json({ error: "Feedback text is required" });

    const reply = await generateReply(feedback);
    res.json({ reply });
  } catch (err) {
    console.error("customer-care error:", err.message);
    res.status(500).json({ error: "Something went wrong" });
  }
});

export default router;
