import { Router } from "express";
import { getModerationQueue } from "../queue.js";
import { requireStoreToken } from "../middleware/auth.js";

const router = Router();

router.post("/moderate", requireStoreToken(["moderate"]), async (req, res) => {
  try {
    const { text, webhookUrl: bodyWebhookUrl, metadata } = req.body;
    if (!text) return res.status(400).json({ error: "Text is required" });

    // For "api" tokens the webhook URL is configured once on the dashboard
    // and lives on the token itself. The consumer doesn't (and shouldn't) need
    // to repeat it on every request. For other store types we fall back to a
    // body-supplied webhookUrl, so platform integrations stay flexible.
    const tokenWebhookUrl = req.storeToken?.webhookUrl;
    const isApi = req.storeToken?.storeType === "api";

    const webhookUrl = isApi
      ? tokenWebhookUrl
      : tokenWebhookUrl || bodyWebhookUrl;

    if (!webhookUrl) {
      return res.status(400).json({
        error: isApi
          ? "This API token has no webhookUrl configured. Set one on the dashboard when creating the token."
          : "webhookUrl is required",
      });
    }

    const queue = getModerationQueue();
    const job = await queue.add("moderate", {
      text,
      webhookUrl,
      metadata: metadata ?? null,
      storeName: req.storeToken?.storeName,
      storeType: req.storeToken?.storeType,
    });

    res.status(202).json({ jobId: job.id, status: "processing" });
  } catch (err) {
    console.error("moderate error:", err.message);
    res.status(500).json({ error: "Something went wrong" });
  }
});

router.get("/jobs/:id", async (req, res) => {
  try {
    const queue = getModerationQueue();
    const job = await queue.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: "Job not found" });

    const state = await job.getState();

    if (state === "completed") {
      return res.json({ jobId: job.id, status: "done", result: job.returnvalue });
    }

    if (state === "failed") {
      return res.json({ jobId: job.id, status: "failed", error: job.failedReason });
    }

    res.json({ jobId: job.id, status: state });
  } catch (err) {
    console.error("job status error:", err.message);
    res.status(500).json({ error: "Something went wrong" });
  }
});

export default router;
