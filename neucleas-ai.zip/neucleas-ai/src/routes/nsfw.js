import { Router } from "express";
import multer from "multer";
import fs from "fs";
import { isNSFW } from "../services/nsfw.js";

const router = Router();
const upload = multer({ dest: "uploads/" });

router.post("/check-image", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Image is required" });

    const imageBuffer = fs.readFileSync(req.file.path);
    const result = await isNSFW(imageBuffer, req.file.mimetype);

    fs.unlinkSync(req.file.path);
    res.json(result);
  } catch (err) {
    console.error("check-image error:", err.message);
    if (req.file?.path) fs.unlinkSync(req.file.path);
    res.status(500).json({ error: "Something went wrong" });
  }
});

export default router;
