import { hf } from "../hfClient.js";

const MODEL = "unitary/toxic-bert";
const ENDPOINT = `https://router.huggingface.co/hf-inference/models/${MODEL}`;
const THRESHOLD = 0.85;

export async function isToxic(text) {
  const output = await hf.textClassification({
    model: MODEL,
    inputs: text,
    endpointUrl: ENDPOINT,
  });

  const score = output.find((o) => o.label === "toxic")?.score ?? 0;
  return { toxic: score > THRESHOLD, score };
}
