import { hf } from "../hfClient.js";

const MODEL = "Falconsai/nsfw_image_detection";
const ENDPOINT = `https://router.huggingface.co/hf-inference/models/${MODEL}`;
const THRESHOLD = 0.85;

export async function isNSFW(imageBuffer, mimeType = "image/jpeg") {
  const output = await hf.imageClassification({
    inputs: new Blob([imageBuffer], { type: mimeType }),
    model: MODEL,
    endpointUrl: ENDPOINT,
  });

  const score = output.find((o) => o.label === "nsfw")?.score ?? 0;
  return { nsfw: score > THRESHOLD, score };
}
