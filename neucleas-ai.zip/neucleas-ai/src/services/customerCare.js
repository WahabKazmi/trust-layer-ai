import { hf } from "../hfClient.js";

const MODEL = "Qwen/Qwen2.5-7B-Instruct";

const SYSTEM_PROMPT = `You are a friendly and professional customer care representative for XYZ Store, an ecommerce company.
When responding to customer feedback:
- Be empathetic, polite, and solution-oriented
- Acknowledge the customer's concern or appreciation
- Offer help or next steps when appropriate
- Keep responses concise (2-4 sentences)
- Never make promises you can't keep (e.g. refunds, discounts) — instead direct them to the support team
- Sign off as "XYZ Store Customer Care"`;

export async function generateReply(feedback) {
  const output = await hf.chatCompletion({
    model: MODEL,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: feedback },
    ],
    max_tokens: 256,
  });

  return output.choices[0].message.content;
}
