import { Queue } from "bullmq";

const REDIS_CONNECTION = {
  host: process.env.REDIS_HOST || "127.0.0.1",
  port: parseInt(process.env.REDIS_PORT || "6379"),
};

const JOB_DEFAULTS = {
  attempts: 3,
  backoff: { type: "exponential", delay: 2000 },
  removeOnComplete: { age: 86400 },
  removeOnFail: { age: 86400 * 3 },
};

let _queue = null;

export function getModerationQueue() {
  if (!_queue) {
    _queue = new Queue("moderation", {
      connection: REDIS_CONNECTION,
      defaultJobOptions: JOB_DEFAULTS,
    });
  }
  return _queue;
}
