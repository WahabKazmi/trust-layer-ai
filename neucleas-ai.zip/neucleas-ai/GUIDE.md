# Trust Layer — Complete Project Guide

> A detailed technical guide for developers and AI agents to fully understand what this project does, how it works, and how every piece fits together.

---

## Table of Contents

1. [What Is This Project?](#1-what-is-this-project)
2. [High-Level Architecture](#2-high-level-architecture)
3. [Directory Structure](#3-directory-structure)
4. [Dependencies](#4-dependencies)
5. [Environment Variables](#5-environment-variables)
6. [Entry Points](#6-entry-points)
7. [Core Modules — Detailed Walkthrough](#7-core-modules--detailed-walkthrough)
   - 7.1 [Hugging Face Client (`src/hfClient.js`)](#71-hugging-face-client-srchfclientjs)
   - 7.2 [Express App (`src/app.js`)](#72-express-app-srcappjs)
   - 7.3 [Toxicity Detection Service (`src/services/toxicity.js`)](#73-toxicity-detection-service-srcservicestoxicityjs)
   - 7.4 [NSFW Image Detection Service (`src/services/nsfw.js`)](#74-nsfw-image-detection-service-srcservicesnsfwjs)
   - 7.5 [Customer Care Service (`src/services/customerCare.js`)](#75-customer-care-service-srcservicescustomercarejs)
   - 7.6 [Toxicity Route (`src/routes/toxicity.js`)](#76-toxicity-route-srcroutestoxicityjs)
   - 7.7 [NSFW Route (`src/routes/nsfw.js`)](#77-nsfw-route-srcroutesnsfwjs)
   - 7.8 [Customer Care Route (`src/routes/customerCare.js`)](#78-customer-care-route-srcroutescustomercarejs)
   - 7.9 [Job Queue (`src/queue.js`)](#79-job-queue-srcqueuejs)
   - 7.10 [Jobs Route (`src/routes/jobs.js`)](#710-jobs-route-srcroutesjobsjs)
   - 7.11 [Worker (`src/worker.js`)](#711-worker-srcworkerjs)
8. [API Reference](#8-api-reference)
9. [Request/Response Flow Diagrams](#9-requestresponse-flow-diagrams)
10. [How to Run](#10-how-to-run)
11. [Key Design Decisions](#11-key-design-decisions)

---

## 1. What Is This Project?

Trust Layer is a **Node.js REST API** for AI-powered content moderation. It provides three core capabilities:

| Capability | What it does | AI Model Used |
|---|---|---|
| **Toxicity Detection** | Classifies text as toxic or safe | `unitary/toxic-bert` (text classification) |
| **NSFW Image Filtering** | Classifies uploaded images as NSFW or safe | `Falconsai/nsfw_image_detection` (image classification) |
| **Customer Care Replies** | Auto-generates empathetic customer support replies from feedback | `Qwen/Qwen2.5-7B-Instruct` (chat completion) |

All three services call **Hugging Face Inference API** models. The project also includes an **asynchronous job queue** (BullMQ + Redis) that combines toxicity detection and customer care reply generation into a single background job, delivering results via webhook.

---

## 2. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        CLIENT                                │
│         (any HTTP client — browser, app, curl, etc.)         │
└──────┬──────────────┬──────────────┬──────────────┬──────────┘
       │              │              │              │
       │ POST         │ POST         │ POST         │ POST
       │ /check-      │ /check-      │ /customer-   │ /moderate
       │ toxicity     │ image        │ care         │ (async)
       │              │              │              │
┌──────▼──────────────▼──────────────▼──────────────▼──────────┐
│                     EXPRESS API SERVER                        │
│                     (index.js → src/app.js)                  │
│                                                              │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐  ┌─────────┐ │
│  │ toxicity │  │  nsfw    │  │ customerCare │  │  jobs   │ │
│  │  route   │  │  route   │  │   route      │  │  route  │ │
│  └────┬─────┘  └────┬─────┘  └──────┬───────┘  └────┬────┘ │
│       │              │               │               │       │
│  ┌────▼─────┐  ┌────▼─────┐  ┌──────▼───────┐  ┌───▼────┐  │
│  │ toxicity │  │  nsfw    │  │ customerCare │  │ queue  │  │
│  │ service  │  │ service  │  │   service    │  │(BullMQ)│  │
│  └────┬─────┘  └────┬─────┘  └──────┬───────┘  └───┬────┘  │
│       │              │               │               │       │
│       └──────────────┴───────┬───────┘               │       │
│                              │                       │       │
│                    ┌─────────▼─────────┐             │       │
│                    │   hfClient.js     │             │       │
│                    │ (HF Inference SDK)│             │       │
│                    └─────────┬─────────┘             │       │
└──────────────────────────────┼───────────────────────┼───────┘
                               │                       │
                    ┌──────────▼──────────┐   ┌───────▼───────┐
                    │  Hugging Face API   │   │     Redis     │
                    │  (remote models)    │   │   (job store) │
                    └─────────────────────┘   └───────┬───────┘
                                                      │
                                              ┌───────▼───────┐
                                              │    WORKER     │
                                              │  (worker.js)  │
                                              │               │
                                              │ 1. isToxic()  │
                                              │ 2. genReply() │
                                              │ 3. webhook    │
                                              └───────────────┘
```

There are **two separate processes** that run independently:

1. **API Server** (`index.js`) — handles HTTP requests, responds synchronously for simple checks, or enqueues jobs for async processing.
2. **Worker** (`worker.js`) — pulls jobs from the Redis-backed BullMQ queue, runs AI inference, and delivers results to a webhook URL.

---

## 3. Directory Structure

```
toxicity-detector/
├── index.js                    # API server entry point
├── worker.js                   # Background worker entry point
├── .env                        # Environment variables (HF_TOKEN, etc.)
├── package-lock.json           # Dependency lockfile
├── landing.html                # Marketing landing page
├── uploads/                    # Temp directory for multer image uploads
└── src/
    ├── app.js                  # Express app setup and route mounting
    ├── hfClient.js             # Hugging Face InferenceClient singleton
    ├── queue.js                # BullMQ queue singleton (Redis-backed)
    ├── worker.js               # BullMQ Worker definition + job processor
    ├── routes/
    │   ├── toxicity.js         # POST /check-toxicity
    │   ├── nsfw.js             # POST /check-image
    │   ├── customerCare.js     # POST /customer-care
    │   └── jobs.js             # POST /moderate + GET /jobs/:id
    └── services/
        ├── toxicity.js         # isToxic(text) — calls toxic-bert
        ├── nsfw.js             # isNSFW(buffer) — calls nsfw_image_detection
        └── customerCare.js     # generateReply(feedback) — calls Qwen 2.5
```

---

## 4. Dependencies

| Package | Version | Purpose |
|---|---|---|
| `express` | ^4.21.2 | HTTP server and routing |
| `@huggingface/inference` | ^4.13.15 | SDK to call Hugging Face Inference API models |
| `bullmq` | ^5.0.0 | Redis-backed job queue for async moderation jobs |
| `dotenv` | ^16.4.7 | Load `.env` file into `process.env` |
| `multer` | ^1.4.5-lts.1 | Multipart form-data parsing for image uploads |
| `nodemon` | ^3.1.14 | (dev) Auto-restart server on file changes |

**External infrastructure required:**
- **Redis** — needed by BullMQ for the job queue. Default: `127.0.0.1:6379`.
- **Hugging Face API** — all AI inference happens remotely via HF's hosted endpoints.

---

## 5. Environment Variables

Defined in `.env` at the project root:

| Variable | Required | Default | Description |
|---|---|---|---|
| `HF_TOKEN` | **Yes** | — | Hugging Face API token. The app exits immediately if missing. |
| `PORT` | No | `3000` | Port for the Express API server. |
| `REDIS_HOST` | No | `127.0.0.1` | Redis host for BullMQ. |
| `REDIS_PORT` | No | `6379` | Redis port for BullMQ. |

---

## 6. Entry Points

### `index.js` — API Server

```js
import "dotenv/config";       // Load .env first
import app from "./src/app.js";

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`API server running on http://localhost:${PORT}`);
});
```

This is a thin wrapper. It loads environment variables, imports the configured Express app, and starts listening. Run with: `node index.js` or `npx nodemon index.js`.

### `worker.js` — Background Worker

```js
import "dotenv/config";
import { startWorker } from "./src/worker.js";

startWorker();
console.log("Worker started — waiting for jobs...");
```

This starts the BullMQ Worker that listens for jobs on the `"moderation"` queue. It runs as a **completely separate process** from the API server. Run with: `node worker.js` or `npx nodemon worker.js`.

---

## 7. Core Modules — Detailed Walkthrough

### 7.1 Hugging Face Client (`src/hfClient.js`)

```js
import { InferenceClient } from "@huggingface/inference";

if (!process.env.HF_TOKEN) {
  console.error("ERROR: HF_TOKEN is not set in .env");
  process.exit(1);
}

export const hf = new InferenceClient(process.env.HF_TOKEN);
```

**What it does:** Creates and exports a single `InferenceClient` instance authenticated with the user's Hugging Face token. Every service file imports this shared `hf` object to make API calls.

**Why it exists:** Centralizes authentication. If the token is missing, the process crashes immediately with a clear error instead of failing silently later.

**Used by:** `src/services/toxicity.js`, `src/services/nsfw.js`, `src/services/customerCare.js`

---

### 7.2 Express App (`src/app.js`)

```js
import express from "express";
import toxicityRoutes from "./routes/toxicity.js";
import nsfwRoutes from "./routes/nsfw.js";
import customerCareRoutes from "./routes/customerCare.js";
import jobRoutes from "./routes/jobs.js";

const app = express();
app.use(express.json());

app.use(toxicityRoutes);
app.use(nsfwRoutes);
app.use(customerCareRoutes);
app.use(jobRoutes);

app.get("/health", (_req, res) => res.json({ status: "ok" }));

export default app;
```

**What it does:** Assembles the Express application. Mounts JSON body parsing middleware, registers all four route modules, and adds a `/health` endpoint for liveness checks.

**Route registration order:** toxicity → nsfw → customerCare → jobs. Since all routes use distinct paths, order doesn't matter functionally.

---

### 7.3 Toxicity Detection Service (`src/services/toxicity.js`)

```js
import { hf } from "../hfClient.js";

const MODEL = "unitary/toxic-bert";
const ENDPOINT = `https://router.huggingface.co/hf-inference/models/${MODEL}`;
const THRESHOLD = 0.85;

export async function isToxic(text) {
  const output = await hf.textClassification({
    model: MODEL,
    inputs: text,
    endpointUrl: ENDPOINT,
  });

  const score = output.find((o) => o.label === "toxic")?.score ?? 0;
  return { toxic: score > THRESHOLD, score };
}
```

**What it does:**
1. Sends the input `text` to the `unitary/toxic-bert` model via HF's text classification API.
2. The model returns an array of `{ label, score }` objects (e.g. `[{ label: "toxic", score: 0.92 }, { label: "not_toxic", score: 0.08 }]`).
3. Extracts the score for the `"toxic"` label.
4. Returns `{ toxic: true/false, score: number }` — `toxic` is `true` only if the score exceeds **0.85**.

**Model:** [unitary/toxic-bert](https://huggingface.co/unitary/toxic-bert) — a BERT model fine-tuned for toxicity classification.

**Threshold:** 0.85. This is a high-confidence threshold — only strongly toxic content gets flagged.

---

### 7.4 NSFW Image Detection Service (`src/services/nsfw.js`)

```js
import { hf } from "../hfClient.js";

const MODEL = "Falconsai/nsfw_image_detection";
const ENDPOINT = `https://router.huggingface.co/hf-inference/models/${MODEL}`;
const THRESHOLD = 0.85;

export async function isNSFW(imageBuffer, mimeType = "image/jpeg") {
  const output = await hf.imageClassification({
    inputs: new Blob([imageBuffer], { type: mimeType }),
    model: MODEL,
    endpointUrl: ENDPOINT,
  });

  const score = output.find((o) => o.label === "nsfw")?.score ?? 0;
  return { nsfw: score > THRESHOLD, score };
}
```

**What it does:**
1. Takes a raw `imageBuffer` (from multer) and wraps it in a `Blob` with the correct MIME type.
2. Sends it to the `Falconsai/nsfw_image_detection` model via HF's image classification API.
3. Finds the `"nsfw"` label score from the results.
4. Returns `{ nsfw: true/false, score: number }`.

**Model:** [Falconsai/nsfw_image_detection](https://huggingface.co/Falconsai/nsfw_image_detection) — a vision model that classifies images as `nsfw` or `normal`.

**Threshold:** 0.85 — same high-confidence approach as toxicity.

---

### 7.5 Customer Care Service (`src/services/customerCare.js`)

```js
import { hf } from "../hfClient.js";

const MODEL = "Qwen/Qwen2.5-7B-Instruct";

const SYSTEM_PROMPT = `You are a friendly and professional customer care representative for XYZ Store...`;

export async function generateReply(feedback) {
  const output = await hf.chatCompletion({
    model: MODEL,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: feedback },
    ],
    max_tokens: 256,
  });

  return output.choices[0].message.content;
}
```

**What it does:**
1. Takes raw customer `feedback` text.
2. Sends it to the `Qwen/Qwen2.5-7B-Instruct` LLM as a chat completion request, with a system prompt that instructs the model to act as a customer care rep for "XYZ Store".
3. Returns the generated reply string.

**System prompt rules:**
- Be empathetic, polite, solution-oriented
- 2–4 sentences
- Never promise refunds/discounts — redirect to support team
- Sign off as "XYZ Store Customer Care"

**Model:** [Qwen/Qwen2.5-7B-Instruct](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct) — a 7B parameter instruction-tuned LLM.

**Token limit:** 256 max output tokens — keeps replies short.

---

### 7.6 Toxicity Route (`src/routes/toxicity.js`)

**Endpoint:** `POST /check-toxicity`

**Request body:**
```json
{ "text": "some message to check" }
```

**Response:**
```json
{ "toxic": false, "score": 0.012 }
```

**Error responses:**
- `400` — if `text` is missing
- `500` — if the HF API call fails

**Flow:** Route receives text → calls `isToxic(text)` → returns result directly. This is a **synchronous** endpoint — the client waits for the AI response.

---

### 7.7 NSFW Route (`src/routes/nsfw.js`)

**Endpoint:** `POST /check-image`

**Request:** Multipart form-data with a field named `image` containing the file.

**How the upload works:**
1. `multer` middleware saves the uploaded file to the `uploads/` directory.
2. The route reads the file back into a buffer with `fs.readFileSync`.
3. Calls `isNSFW(imageBuffer, mimeType)`.
4. **Deletes the temp file** with `fs.unlinkSync` (also in the error handler — ensures cleanup).

**Response:**
```json
{ "nsfw": false, "score": 0.03 }
```

**Error responses:**
- `400` — if no image is uploaded
- `500` — if the HF API call fails

---

### 7.8 Customer Care Route (`src/routes/customerCare.js`)

**Endpoint:** `POST /customer-care`

**Request body:**
```json
{ "feedback": "Your product arrived broken and I'm very upset!" }
```

**Response:**
```json
{
  "reply": "We're truly sorry to hear about your experience..."
}
```

**Error responses:**
- `400` — if `feedback` is missing
- `500` — if the HF API call fails

---

### 7.9 Job Queue (`src/queue.js`)

```js
import { Queue } from "bullmq";

const REDIS_CONNECTION = {
  host: process.env.REDIS_HOST || "127.0.0.1",
  port: parseInt(process.env.REDIS_PORT || "6379"),
};

const JOB_DEFAULTS = {
  attempts: 3,
  backoff: { type: "exponential", delay: 2000 },
  removeOnComplete: { age: 86400 },
  removeOnFail: { age: 86400 * 3 },
};

let _queue = null;

export function getModerationQueue() {
  if (!_queue) {
    _queue = new Queue("moderation", {
      connection: REDIS_CONNECTION,
      defaultJobOptions: JOB_DEFAULTS,
    });
  }
  return _queue;
}
```

**What it does:** Creates and exports a **singleton** BullMQ `Queue` named `"moderation"`.

**Job defaults explained:**
| Option | Value | Meaning |
|---|---|---|
| `attempts` | 3 | Retry failed jobs up to 3 times |
| `backoff.type` | `"exponential"` | Wait 2s, then 4s, then 8s between retries |
| `backoff.delay` | 2000 | Base delay is 2 seconds |
| `removeOnComplete.age` | 86400 (24h) | Completed jobs are auto-cleaned after 1 day |
| `removeOnFail.age` | 259200 (72h) | Failed jobs are kept for 3 days for debugging |

**Singleton pattern:** `_queue` is lazily initialized — the first call creates it, subsequent calls return the same instance. This avoids creating duplicate Redis connections.

---

### 7.10 Jobs Route (`src/routes/jobs.js`)

This file defines **two endpoints** for async moderation:

#### `POST /moderate`

**Request body:**
```json
{
  "text": "some user-generated content",
  "webhookUrl": "https://your-server.com/webhook"
}
```

**What happens:**
1. Validates `text` and `webhookUrl` are present.
2. Adds a new job named `"moderate"` to the `"moderation"` queue with the data `{ text, webhookUrl }`.
3. Immediately returns `202 Accepted` with the job ID:

```json
{ "jobId": "1", "status": "processing" }
```

The actual processing happens in the Worker (separate process). The client can either:
- Wait for the webhook callback, or
- Poll the job status endpoint.

#### `GET /jobs/:id`

**What happens:**
1. Looks up the job by ID in the queue.
2. Returns the current state:

```json
// Completed
{ "jobId": "1", "status": "done", "result": { "toxic": false, "score": 0.01, "reply": "..." } }

// Still processing
{ "jobId": "1", "status": "active" }

// Failed
{ "jobId": "1", "status": "failed", "error": "Webhook failed with status 500" }
```

**Possible states:** `waiting`, `active`, `completed` (returned as `"done"`), `failed`, `delayed`.

---

### 7.11 Worker (`src/worker.js`)

```js
import { Worker } from "bullmq";
import { isToxic } from "./services/toxicity.js";
import { generateReply } from "./services/customerCare.js";

async function processModeration(job) {
  const { text, webhookUrl } = job.data;

  const [toxicity, reply] = await Promise.all([
    isToxic(text),
    generateReply(text),
  ]);

  const result = { ...toxicity, reply };

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jobId: job.id, status: "done", result }),
  });

  if (!response.ok) {
    throw new Error(`Webhook failed with status ${response.status}`);
  }

  return result;
}

export function startWorker() {
  const worker = new Worker("moderation", processModeration, {
    connection: REDIS_CONNECTION,
    concurrency: 3,
  });

  worker.on("completed", (job) => console.log(`Job ${job.id} completed`));
  worker.on("failed", (job, err) => console.error(`Job ${job?.id} failed:`, err.message));

  return worker;
}
```

**What it does — step by step:**

1. **Picks up a job** from the `"moderation"` queue in Redis.
2. **Runs two AI calls in parallel** using `Promise.all`:
   - `isToxic(text)` — toxicity classification
   - `generateReply(text)` — customer care reply generation
3. **Merges results** into a single object: `{ toxic, score, reply }`.
4. **POSTs the result** to the `webhookUrl` provided by the client.
5. **If the webhook fails** (non-2xx status), throws an error — BullMQ will retry the job (up to 3 attempts with exponential backoff).
6. **Returns the result** — BullMQ stores it as `job.returnvalue` (accessible via `GET /jobs/:id`).

**Concurrency:** `3` — the worker processes up to 3 jobs simultaneously.

**Important:** The webhook delivery is part of the job. If the webhook fails, the entire job is retried — including the AI calls. This is a tradeoff for simplicity.

---

## 8. API Reference

| Method | Path | Body | Response | Type |
|---|---|---|---|---|
| `POST` | `/check-toxicity` | `{ text }` | `{ toxic, score }` | Sync |
| `POST` | `/check-image` | `multipart: image` | `{ nsfw, score }` | Sync |
| `POST` | `/customer-care` | `{ feedback }` | `{ reply }` | Sync |
| `POST` | `/moderate` | `{ text, webhookUrl }` | `{ jobId, status }` | Async (202) |
| `GET` | `/jobs/:id` | — | `{ jobId, status, result? }` | Poll |
| `GET` | `/health` | — | `{ status: "ok" }` | Health check |

---

## 9. Request/Response Flow Diagrams

### Synchronous Flow (e.g. `/check-toxicity`)

```
Client                API Server              Hugging Face
  │                       │                        │
  │  POST /check-toxicity │                        │
  │  { text: "hello" }    │                        │
  │──────────────────────>│                        │
  │                       │  textClassification()  │
  │                       │───────────────────────>│
  │                       │                        │
  │                       │  [{ label, score }...] │
  │                       │<───────────────────────│
  │                       │                        │
  │  { toxic: false,      │                        │
  │    score: 0.01 }      │                        │
  │<──────────────────────│                        │
```

### Asynchronous Flow (`/moderate`)

```
Client              API Server         Redis/Queue         Worker           Your Webhook
  │                     │                   │                 │                   │
  │ POST /moderate      │                   │                 │                   │
  │ { text, webhookUrl }│                   │                 │                   │
  │────────────────────>│                   │                 │                   │
  │                     │  queue.add()      │                 │                   │
  │                     │──────────────────>│                 │                   │
  │                     │                   │                 │                   │
  │ 202 { jobId: "1",   │                   │                 │                   │
  │   status:"processing"}                  │                 │                   │
  │<────────────────────│                   │                 │                   │
  │                     │                   │  pick up job    │                   │
  │                     │                   │────────────────>│                   │
  │                     │                   │                 │                   │
  │                     │                   │                 │── isToxic()       │
  │                     │                   │                 │── generateReply() │
  │                     │                   │                 │   (parallel)      │
  │                     │                   │                 │                   │
  │                     │                   │                 │  POST webhook     │
  │                     │                   │                 │──────────────────>│
  │                     │                   │                 │                   │
  │                     │                   │  job complete   │                   │
  │                     │                   │<────────────────│                   │
  │                     │                   │                 │                   │
  │ GET /jobs/1         │                   │                 │                   │
  │────────────────────>│  getJob("1")      │                 │                   │
  │                     │──────────────────>│                 │                   │
  │                     │  returnvalue      │                 │                   │
  │                     │<──────────────────│                 │                   │
  │ { jobId: "1",       │                   │                 │                   │
  │   status: "done",   │                   │                 │                   │
  │   result: {...} }   │                   │                 │                   │
  │<────────────────────│                   │                 │                   │
```

---

## 10. How to Run

### Prerequisites

- Node.js (v18+ recommended for native `fetch`)
- Redis running locally (for the job queue / worker)
- A Hugging Face API token

### Setup

```bash
# 1. Install dependencies
npm install

# 2. Create .env file
echo "HF_TOKEN=hf_your_token_here" > .env

# 3. Start Redis (if not already running)
redis-server

# 4. Start the API server
node index.js
# or with auto-reload:
npx nodemon index.js

# 5. Start the worker (in a separate terminal)
node worker.js
# or with auto-reload:
npx nodemon worker.js
```

### Quick Test

```bash
# Toxicity check
curl -X POST http://localhost:3000/check-toxicity \
  -H "Content-Type: application/json" \
  -d '{"text": "You are amazing!"}'

# NSFW image check
curl -X POST http://localhost:3000/check-image \
  -F "image=@photo.jpg"

# Customer care reply
curl -X POST http://localhost:3000/customer-care \
  -H "Content-Type: application/json" \
  -d '{"feedback": "My order arrived damaged"}'

# Async moderation
curl -X POST http://localhost:3000/moderate \
  -H "Content-Type: application/json" \
  -d '{"text": "some content", "webhookUrl": "https://your-server.com/hook"}'

# Check job status
curl http://localhost:3000/jobs/1

# Health check
curl http://localhost:3000/health
```

---

## 11. Key Design Decisions

| Decision | Rationale |
|---|---|
| **Hugging Face Inference API (not local models)** | No GPU required. Models run on HF's servers. Tradeoff: depends on external service + network latency. |
| **0.85 threshold for toxicity and NSFW** | High-confidence threshold minimizes false positives. Adjustable per use case. |
| **BullMQ + Redis for async jobs** | Production-grade job queue with retry logic, backoff, and job status tracking. Avoids losing jobs if the server restarts. |
| **Webhook delivery in the worker** | Clients don't have to poll — they receive results pushed to them. Webhook failure triggers a job retry. |
| **`Promise.all` for parallel AI calls** | The worker runs toxicity check and reply generation simultaneously, cutting job time roughly in half. |
| **Singleton patterns (hfClient, queue)** | Prevents duplicate connections and ensures consistent state across the app. |
| **Multer with temp file + cleanup** | Simple approach for image uploads. Files are deleted immediately after processing (or on error). |
| **Separate server and worker processes** | Decouples HTTP handling from heavy AI work. The server stays responsive; the worker can be scaled independently. |
| **`concurrency: 3` on the worker** | Processes 3 jobs at once. Tunable based on HF rate limits and available resources. |
| **Exponential backoff on retries** | Prevents hammering a failing service. Waits 2s → 4s → 8s. |
