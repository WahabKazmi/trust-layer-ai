import { api } from "./api";

export interface UserProfile {
  id: string;
  email: string;
  name: string | null;
  role: string;
  emailVerified: boolean;
  oauthProvider: string | null;
  createdAt: string;
  updatedAt: string;
}

interface UsersListResponse {
  users: UserProfile[];
  total: number;
  page: number;
  limit: number;
}

export const userApi = api.injectEndpoints({
  endpoints: (build) => ({
    getMe: build.query<UserProfile, void>({
      query: () => "/users/me",
      providesTags: ["User"],
    }),
    updateMe: build.mutation<UserProfile, { name?: string; email?: string }>({
      query: (body) => ({ url: "/users/me", method: "PATCH", body }),
      invalidatesTags: ["User"],
    }),
    deleteMe: build.mutation<{ message: string }, void>({
      query: () => ({ url: "/users/me", method: "DELETE" }),
      invalidatesTags: ["User"],
    }),
    listUsers: build.query<UsersListResponse, { page?: number; limit?: number }>({
      query: ({ page = 1, limit = 20 } = {}) =>
        `/users?page=${page}&limit=${limit}`,
      providesTags: ["Users"],
    }),
    changeRole: build.mutation<UserProfile, { id: string; role: string }>({
      query: ({ id, role }) => ({
        url: `/users/${id}/role`,
        method: "PATCH",
        body: { role },
      }),
      invalidatesTags: ["Users"],
    }),
  }),
});

export const {
  useGetMeQuery,
  useUpdateMeMutation,
  useDeleteMeMutation,
  useListUsersQuery,
  useChangeRoleMutation,
} = userApi;
