import { api } from "./api";

export interface StoreToken {
  id: string;
  storeName: string;
  storeUrl: string;
  storeType: string;
  scopes: string[];
  webhookUrl?: string | null;
  expiresAt: string | null;
  revoked: boolean;
  createdAt: string;
}

interface CreateStoreTokenRequest {
  storeName: string;
  storeUrl: string;
  storeType: string;
  scopes: string[];
  webhookUrl?: string;
  expiresInDays?: number;
}

interface CreateStoreTokenResponse extends StoreToken {
  token: string;
  message: string;
}

export interface UpdateStoreTokenRequest {
  id: string;
  storeName?: string;
  storeUrl?: string;
  scopes?: string[];
  webhookUrl?: string | null;
  expiresInDays?: number | null;
}

export const storeTokenApi = api.injectEndpoints({
  endpoints: (build) => ({
    listStoreTokens: build.query<StoreToken[], void>({
      query: () => "/store-tokens",
      providesTags: ["StoreTokens"],
    }),
    createStoreToken: build.mutation<
      CreateStoreTokenResponse,
      CreateStoreTokenRequest
    >({
      query: (body) => ({ url: "/store-tokens", method: "POST", body }),
      invalidatesTags: ["StoreTokens"],
    }),
    updateStoreToken: build.mutation<StoreToken, UpdateStoreTokenRequest>({
      query: ({ id, ...body }) => ({
        url: `/store-tokens/${id}`,
        method: "PATCH",
        body,
      }),
      invalidatesTags: ["StoreTokens"],
    }),
    revokeStoreToken: build.mutation<{ message: string }, string>({
      query: (id) => ({ url: `/store-tokens/${id}/revoke`, method: "POST" }),
      invalidatesTags: ["StoreTokens"],
    }),
    deleteStoreToken: build.mutation<{ message: string }, string>({
      query: (id) => ({ url: `/store-tokens/${id}`, method: "DELETE" }),
      invalidatesTags: ["StoreTokens"],
    }),
  }),
});

export const {
  useListStoreTokensQuery,
  useCreateStoreTokenMutation,
  useUpdateStoreTokenMutation,
  useRevokeStoreTokenMutation,
  useDeleteStoreTokenMutation,
} = storeTokenApi;
