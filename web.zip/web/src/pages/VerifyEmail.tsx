import { Card, Typography, Spin, Result } from "antd";
import { useSearchParams, Link } from "react-router-dom";
import { useVerifyEmailQuery } from "../store/authApi";

const AUTH_BG = { background: "linear-gradient(135deg, #f0f4f8 0%, #e8ecf1 50%, #f5f7fa 100%)" };
const AUTH_CARD = { boxShadow: "0 8px 40px rgba(0,0,0,0.06)", border: "1px solid #e5e7eb", borderRadius: 20 };

export default function VerifyEmail() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token") || "";

  const { isLoading, isSuccess, isError, error } = useVerifyEmailQuery(token, {
    skip: !token,
  });

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={AUTH_BG}>
      <Card className="w-full max-w-md text-center" style={AUTH_CARD} bordered={false}>
        {!token && (
          <Result status="error" title="Invalid Verification Link" subTitle="The verification link is missing or invalid." />
        )}
        {isLoading && (
          <div className="py-8">
            <Spin size="large" />
            <Typography.Text className="block mt-4">Verifying your email...</Typography.Text>
          </div>
        )}
        {isSuccess && (
          <Result
            status="success"
            title="Email Verified!"
            subTitle="Your email has been verified. You can now log in."
            extra={<Link to="/login"><Typography.Link strong>Go to Login</Typography.Link></Link>}
          />
        )}
        {isError && (
          <Result
            status="error"
            title="Verification Failed"
            subTitle={(error as any)?.data?.error || "The token is invalid or expired."}
          />
        )}
      </Card>
    </div>
  );
}
