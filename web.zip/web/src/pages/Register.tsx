import { Button, Card, Form, Input, Typography, Divider, message } from "antd";
import {
  MailOutlined,
  LockOutlined,
  UserOutlined,
  GoogleOutlined,
  GithubOutlined,
} from "@ant-design/icons";
import { Link, useNavigate } from "react-router-dom";
import { useRegisterMutation } from "../store/authApi";

const AUTH_BG = { background: "linear-gradient(135deg, #f0f4f8 0%, #e8ecf1 50%, #f5f7fa 100%)" };
const AUTH_CARD = { boxShadow: "0 8px 40px rgba(0,0,0,0.06)", border: "1px solid #e5e7eb", borderRadius: 20 };
const LOGO_BLOB = { width: 44, height: 44, background: "rgba(75,106,136,0.1)", borderRadius: "50% 50% 50% 20%", fontSize: 22 };

export default function Register() {
  const [register, { isLoading }] = useRegisterMutation();
  const navigate = useNavigate();

  const onFinish = async (values: { name: string; email: string; password: string }) => {
    try {
      await register(values).unwrap();
      message.success("Registration successful! Check your email to verify.");
      navigate("/login");
    } catch (err: any) {
      message.error(err?.data?.error || "Registration failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={AUTH_BG}>
      <Card className="w-full max-w-md" style={AUTH_CARD} bordered={false}>
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2.5 mb-5">
            <div className="flex items-center justify-center" style={LOGO_BLOB}>🛡️</div>
            <span className="font-extrabold text-xl" style={{ color: "#1b2b3a" }}>Trust Layer</span>
          </div>
          <Typography.Title level={3} className="!mb-1" style={{ fontWeight: 800 }}>
            Create your account
          </Typography.Title>
          <Typography.Text type="secondary">Get started with Trust Layer for free</Typography.Text>
        </div>

        <Form layout="vertical" onFinish={onFinish} requiredMark={false} size="large">
          <Form.Item name="name" rules={[{ required: true, message: "Name is required" }]}>
            <Input prefix={<UserOutlined className="text-gray-400" />} placeholder="Full name" />
          </Form.Item>
          <Form.Item name="email" rules={[{ required: true, message: "Email is required" }, { type: "email", message: "Enter a valid email" }]}>
            <Input prefix={<MailOutlined className="text-gray-400" />} placeholder="Email address" />
          </Form.Item>
          <Form.Item name="password" rules={[{ required: true, message: "Password is required" }, { min: 8, message: "At least 8 characters" }]}>
            <Input.Password prefix={<LockOutlined className="text-gray-400" />} placeholder="Password" />
          </Form.Item>
          <Form.Item
            name="confirm"
            dependencies={["password"]}
            rules={[
              { required: true, message: "Confirm your password" },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) return Promise.resolve();
                  return Promise.reject(new Error("Passwords do not match"));
                },
              }),
            ]}
          >
            <Input.Password prefix={<LockOutlined className="text-gray-400" />} placeholder="Confirm password" />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" block size="large" loading={isLoading} style={{ height: 48, fontWeight: 700, fontSize: 15 }}>
              Create Account
            </Button>
          </Form.Item>
        </Form>

        <Divider plain className="!text-gray-400 !text-xs">or continue with</Divider>
        <div className="flex gap-3">
          <Button icon={<GoogleOutlined />} block size="large" href="/api/auth/google" style={{ fontWeight: 600 }}>Google</Button>
          <Button icon={<GithubOutlined />} block size="large" href="/api/auth/github" style={{ fontWeight: 600 }}>GitHub</Button>
        </div>
        <div className="text-center mt-6">
          <Typography.Text type="secondary">
            Already have an account?{" "}
            <Link to="/login"><Typography.Link strong>Sign in</Typography.Link></Link>
          </Typography.Text>
        </div>
      </Card>
    </div>
  );
}
