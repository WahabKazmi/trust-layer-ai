import { useState } from "react";
import {
  Card,
  Typography,
  Table,
  Tag,
  Select,
  message,
} from "antd";
import { CheckCircleOutlined, WarningOutlined } from "@ant-design/icons";
import {
  useListUsersQuery,
  useChangeRoleMutation,
  type UserProfile,
} from "../store/userApi";

const ROLE_COLORS: Record<string, { bg: string; border: string; text: string }> = {
  USER: { bg: "#eef2f7", border: "#dbe3ed", text: "#4B6A88" },
  MODERATOR: { bg: "#fefce8", border: "#fde68a", text: "#a16207" },
  ADMIN: { bg: "#fef2f2", border: "#fecaca", text: "#dc2626" },
};

export default function AdminUsers() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useListUsersQuery({ page, limit: 20 });
  const [changeRole] = useChangeRoleMutation();

  const handleRoleChange = async (userId: string, role: string) => {
    try {
      await changeRole({ id: userId, role }).unwrap();
      message.success("Role updated");
    } catch (err: any) {
      message.error(err?.data?.error || "Failed to update role");
    }
  };

  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      render: (v: string | null) => (
        <span className="font-semibold">{v || "-"}</span>
      ),
    },
    { title: "Email", dataIndex: "email", key: "email" },
    {
      title: "Verified",
      dataIndex: "emailVerified",
      key: "emailVerified",
      render: (v: boolean) =>
        v ? (
          <Tag icon={<CheckCircleOutlined />} color="success">
            Yes
          </Tag>
        ) : (
          <Tag icon={<WarningOutlined />} color="warning">
            No
          </Tag>
        ),
    },
    {
      title: "Provider",
      dataIndex: "oauthProvider",
      key: "oauthProvider",
      render: (v: string | null) =>
        v ? <Tag color="purple">{v}</Tag> : <span className="text-gray-400">Email</span>,
    },
    {
      title: "Role",
      key: "role",
      render: (_: unknown, record: UserProfile) => {
        const colors = ROLE_COLORS[record.role] || ROLE_COLORS.USER;
        return (
          <Select
            value={record.role}
            onChange={(role) => handleRoleChange(record.id, role)}
            size="small"
            style={{ width: 140 }}
            options={Object.entries(ROLE_COLORS).map(([role, c]) => ({
              label: (
                <Tag style={{ background: c.bg, border: `1px solid ${c.border}`, color: c.text, fontWeight: 600 }}>
                  {role}
                </Tag>
              ),
              value: role,
            }))}
          />
        );
      },
    },
    {
      title: "Joined",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (v: string) =>
        new Date(v).toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "numeric",
        }),
    },
  ];

  return (
    <div>
      <Typography.Title level={3} style={{ fontWeight: 800 }}>
        User Management
      </Typography.Title>

      <Card>
        <Table
          dataSource={data?.users}
          columns={columns}
          rowKey="id"
          loading={isLoading}
          pagination={{
            current: page,
            total: data?.total,
            pageSize: 20,
            onChange: (p) => setPage(p),
            showTotal: (total) => `${total} users`,
          }}
        />
      </Card>
    </div>
  );
}
