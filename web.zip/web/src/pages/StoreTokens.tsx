import { useEffect, useState } from "react";
import {
  Card,
  Typography,
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  InputNumber,
  Tag,
  Tooltip,
  Avatar,
  message,
  Alert,
  Dropdown,
} from "antd";
import {
  PlusOutlined,
  StopOutlined,
  CopyOutlined,
  EditOutlined,
  DeleteOutlined,
  MoreOutlined,
} from "@ant-design/icons";
import type { ReactNode } from "react";
import {
  useListStoreTokensQuery,
  useCreateStoreTokenMutation,
  useUpdateStoreTokenMutation,
  useRevokeStoreTokenMutation,
  useDeleteStoreTokenMutation,
  type StoreToken,
} from "../store/storeTokenApi";

const SCOPE_OPTIONS = [
  { label: "Toxicity", value: "toxicity" },
  { label: "NSFW", value: "nsfw" },
  { label: "Customer Care", value: "customer-care" },
  { label: "Moderate (async)", value: "moderate" },
];

const PLATFORM_ICONS: Record<string, string> = {
  api: "https://cdn.simpleicons.org/openapiinitiative/4B6A88",
  woocommerce: "https://cdn.simpleicons.org/woocommerce/96588A",
  shopify: "https://cdn.simpleicons.org/shopify/7AB55C",
  magento: "https://cdn.simpleicons.org/adobecommerce/F46F25",
  bigcommerce: "https://cdn.simpleicons.org/bigcommerce/121118",
  prestashop: "https://cdn.simpleicons.org/prestashop/DF0067",
  opencart: "https://cdn.simpleicons.org/opencart/23A4DE",
};

const STORE_TYPE_OPTIONS = [
  { label: "Custom API (any platform)", value: "api", disabled: false },
  { label: "WooCommerce", value: "woocommerce", disabled: false },
  { label: "Shopify", value: "shopify", disabled: false },
  { label: "Magento", value: "magento", disabled: true },
  { label: "BigCommerce", value: "bigcommerce", disabled: true },
  { label: "PrestaShop", value: "prestashop", disabled: true },
  { label: "OpenCart", value: "opencart", disabled: true },
];

const STORE_TYPE_LABELS: Record<string, string> = {
  api: "Custom API",
  woocommerce: "WooCommerce",
  shopify: "Shopify",
  magento: "Magento",
  bigcommerce: "BigCommerce",
  prestashop: "PrestaShop",
  opencart: "OpenCart",
};

function SiteThumbnail({ url, name }: { url?: string; name: string }) {
  let domain = "";
  try {
    if (url) domain = new URL(url).hostname;
  } catch {
    // invalid URL
  }

  if (!domain) {
    return (
      <Avatar
        shape="square"
        size={36}
        style={{
          background: "#4B6A88",
          fontWeight: 700,
          borderRadius: 10,
          flexShrink: 0,
        }}
      >
        {name.charAt(0).toUpperCase()}
      </Avatar>
    );
  }

  return (
    <img
      src={`https://icon.horse/icon/${domain}`}
      alt={domain}
      referrerPolicy="no-referrer"
      className="w-9 h-9 rounded-lg object-contain bg-gray-50 shrink-0"
      onError={(e) => {
        const el = e.target as HTMLImageElement;
        if (!el.dataset.fallback) {
          el.dataset.fallback = "1";
          el.src = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
        } else {
          el.onerror = null;
          el.style.display = "none";
        }
      }}
    />
  );
}

function PlatformIcon({ type }: { type: string }) {
  const src = PLATFORM_ICONS[type];
  if (!src) return null;
  return <img src={src} alt={type} className="w-5 h-5 inline-block" />;
}

type Mode = "create" | "edit";

interface FormValues {
  storeName: string;
  storeUrl: string;
  storeType: string;
  scopes: string[];
  webhookUrl?: string;
  expiresInDays?: number | null;
}

export default function StoreTokens() {
  const { data: tokens, isLoading } = useListStoreTokensQuery();
  const [createToken, { isLoading: creating }] = useCreateStoreTokenMutation();
  const [updateToken, { isLoading: updating }] = useUpdateStoreTokenMutation();
  const [revokeToken] = useRevokeStoreTokenMutation();
  const [deleteToken] = useDeleteStoreTokenMutation();

  const [modalOpen, setModalOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("create");
  const [editing, setEditing] = useState<StoreToken | null>(null);
  const [newToken, setNewToken] = useState<string | null>(null);
  const [form] = Form.useForm<FormValues>();
  const [modal, modalContextHolder] = Modal.useModal();

  // When opening the modal in edit mode, prefill the form with the token's
  // current values. We can't show or rotate the secret itself.
  useEffect(() => {
    if (modalOpen && mode === "edit" && editing) {
      form.setFieldsValue({
        storeName: editing.storeName,
        storeUrl: editing.storeUrl,
        storeType: editing.storeType,
        scopes: editing.scopes,
        webhookUrl: editing.webhookUrl ?? undefined,
        expiresInDays: undefined,
      });
    }
  }, [modalOpen, mode, editing, form]);

  // For "api" tokens, `moderate` is the only scope the AI worker actually
  // checks (it gates the async /moderate endpoint). An api token without it
  // is dead-on-arrival — the POC store, and any consumer using the webhook
  // flow, would get 403s. So whenever the user picks Custom API we make sure
  // `moderate` is selected, and we render it as a non-removable chip below.
  const watchedStoreType = Form.useWatch("storeType", form);
  useEffect(() => {
    if (!modalOpen) return;
    if (watchedStoreType !== "api") return;
    const current: string[] = form.getFieldValue("scopes") ?? [];
    if (!current.includes("moderate")) {
      form.setFieldsValue({ scopes: [...current, "moderate"] });
    }
  }, [watchedStoreType, modalOpen, form]);

  const openCreate = () => {
    setMode("create");
    setEditing(null);
    setNewToken(null);
    form.resetFields();
    setModalOpen(true);
  };

  const openEdit = (record: StoreToken) => {
    setMode("edit");
    setEditing(record);
    setNewToken(null);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setNewToken(null);
    setEditing(null);
    form.resetFields();
  };

  const handleSubmit = async (values: FormValues) => {
    try {
      if (mode === "create") {
        const payload = {
          ...values,
          webhookUrl:
            values.storeType === "api" && values.webhookUrl
              ? values.webhookUrl
              : undefined,
          expiresInDays: values.expiresInDays ?? undefined,
        };
        const res = await createToken(payload).unwrap();
        setNewToken(res.token);
        form.resetFields();
        message.success("Store token created");
      } else if (mode === "edit" && editing) {
        await updateToken({
          id: editing.id,
          storeName: values.storeName,
          storeUrl: values.storeUrl,
          scopes: values.scopes,
          // For non-api tokens we don't show the field — leave it untouched.
          webhookUrl:
            editing.storeType === "api"
              ? values.webhookUrl ?? null
              : undefined,
          // expiresInDays is a "shift forward by N days from now" knob; only
          // send it when the user actually picked a value.
          expiresInDays: values.expiresInDays ?? undefined,
        }).unwrap();
        message.success("Store token updated");
        closeModal();
      }
    } catch (err: any) {
      message.error(
        err?.data?.error ||
          (mode === "create" ? "Failed to create token" : "Failed to update token")
      );
    }
  };

  const confirmRevoke = (record: StoreToken) => {
    modal.confirm({
      title: "Revoke this token?",
      icon: <StopOutlined style={{ color: "#dc2626" }} />,
      content: (
        <span>
          <b>{record.storeName}</b> will stop validating immediately, but the
          row stays in the list as audit history. You can't undo a revoke from
          the dashboard.
        </span>
      ),
      okText: "Revoke",
      okButtonProps: { danger: true },
      cancelText: "Cancel",
      async onOk() {
        try {
          await revokeToken(record.id).unwrap();
          message.success("Token revoked");
        } catch (err: any) {
          message.error(err?.data?.error || "Failed to revoke");
          throw err;
        }
      },
    });
  };

  const confirmDelete = (record: StoreToken) => {
    modal.confirm({
      title: "Delete this token?",
      icon: <DeleteOutlined style={{ color: "#dc2626" }} />,
      content: (
        <span>
          This permanently removes <b>{record.storeName}</b>. Any consumer
          still using this token will start getting <code>401</code>s. This
          cannot be undone.
        </span>
      ),
      okText: "Delete",
      okButtonProps: { danger: true },
      cancelText: "Cancel",
      async onOk() {
        try {
          await deleteToken(record.id).unwrap();
          message.success("Token deleted");
        } catch (err: any) {
          message.error(err?.data?.error || "Failed to delete");
          throw err;
        }
      },
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    message.success("Copied to clipboard");
  };

  const columns = [
    {
      title: "Store",
      key: "store",
      render: (_: unknown, record: StoreToken) => (
        <div className="flex items-center gap-3">
          <SiteThumbnail url={record.storeUrl} name={record.storeName} />
          <div>
            <div className="font-semibold text-gray-800">{record.storeName}</div>
            {record.storeUrl && (
              <a
                href={record.storeUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-gray-400 hover:text-slate-700"
              >
                {record.storeUrl}
              </a>
            )}
          </div>
        </div>
      ),
    },
    {
      title: "Platform",
      dataIndex: "storeType",
      key: "storeType",
      align: "center" as const,
      render: (v: string) => (
        <Tooltip title={STORE_TYPE_LABELS[v] || v}>
          <img
            src={PLATFORM_ICONS[v]}
            alt={STORE_TYPE_LABELS[v] || v}
            className="w-7 h-7 inline-block"
          />
        </Tooltip>
      ),
    },
    {
      title: "Scopes",
      dataIndex: "scopes",
      key: "scopes",
      render: (scopes: string[]) =>
        scopes.map((s) => (
          <Tag
            key={s}
            style={{
              background: "#eef2f7",
              border: "1px solid #dbe3ed",
              color: "#4B6A88",
              fontWeight: 600,
            }}
          >
            {s}
          </Tag>
        )),
    },
    {
      title: "Webhook",
      key: "webhookUrl",
      render: (_: unknown, record: StoreToken) => {
        if (record.storeType !== "api") {
          return <span className="text-gray-300">—</span>;
        }
        if (!record.webhookUrl) {
          return <Tag color="orange">not set</Tag>;
        }
        return (
          <Tooltip title={record.webhookUrl}>
            <span className="font-mono text-xs text-gray-500 max-w-[220px] inline-block truncate align-middle">
              {record.webhookUrl}
            </span>
          </Tooltip>
        );
      },
    },
    {
      title: "Status",
      key: "status",
      render: (_: unknown, record: StoreToken) => {
        if (record.revoked) return <Tag color="red">Revoked</Tag>;
        if (record.expiresAt && new Date(record.expiresAt) < new Date())
          return <Tag color="orange">Expired</Tag>;
        return <Tag color="success">Active</Tag>;
      },
    },
    {
      title: "Expires",
      dataIndex: "expiresAt",
      key: "expiresAt",
      render: (v: string | null) =>
        v ? new Date(v).toLocaleDateString() : "Never",
    },
    {
      title: "Created",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (v: string) => new Date(v).toLocaleDateString(),
    },
    {
      title: "",
      key: "action",
      width: 56,
      align: "center" as const,
      render: (_: unknown, record: StoreToken) => {
        const items: MenuProps["items"] = [
          {
            key: "edit",
            icon: <EditOutlined />,
            label: "Edit",
            disabled: record.revoked,
            onClick: () => openEdit(record),
          },
          {
            key: "revoke",
            icon: <StopOutlined />,
            label: "Revoke",
            disabled: record.revoked,
            onClick: () => confirmRevoke(record),
          },
          { type: "divider" as const },
          {
            key: "delete",
            icon: <DeleteOutlined />,
            label: "Delete",
            danger: true,
            onClick: () => confirmDelete(record),
          },
        ];
        return (
          <Dropdown
            menu={{ items }}
            trigger={["click"]}
            placement="bottomRight"
          >
            <Button
              type="text"
              shape="circle"
              icon={<MoreOutlined />}
              aria-label="Token actions"
            />
          </Dropdown>
        );
      },
    },
  ];

  return (
    <div>
      {modalContextHolder}
      <div className="flex items-center justify-between mb-5">
        <Typography.Title level={3} className="!mb-0" style={{ fontWeight: 800 }}>
          Store Tokens
        </Typography.Title>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          size="large"
          onClick={openCreate}
          style={{ fontWeight: 600 }}
        >
          Create Token
        </Button>
      </div>

      <Card>
        <Table
          dataSource={tokens}
          columns={columns}
          rowKey="id"
          loading={isLoading}
          pagination={false}
          locale={{ emptyText: "No store tokens yet" }}
        />
      </Card>

      <Modal
        title={mode === "edit" ? "Edit Store Token" : "Create Store Token"}
        open={modalOpen}
        onCancel={closeModal}
        footer={
          newToken
            ? [
                <Button key="close" onClick={closeModal}>
                  Done
                </Button>,
              ]
            : undefined
        }
        onOk={newToken ? undefined : () => form.submit()}
        confirmLoading={mode === "edit" ? updating : creating}
        okText={mode === "edit" ? "Save changes" : "Create"}
      >
        {newToken ? (
          <div>
            <Alert
              message="Save this token now — you won't be able to see it again."
              type="warning"
              showIcon
              className="mb-4"
            />
            <div
              className="flex items-center gap-2 p-3 rounded-lg font-mono text-xs break-all"
              style={{ background: "#f5f7fa", border: "1px solid #dbe3ed", color: "#1b2b3a" }}
            >
              {newToken}
              <Button
                icon={<CopyOutlined />}
                size="small"
                type="text"
                onClick={() => copyToClipboard(newToken)}
              />
            </div>
          </div>
        ) : (
          <Form form={form} layout="vertical" onFinish={handleSubmit}>
            <Form.Item
              name="storeName"
              label="Store Name"
              rules={[{ required: true, message: "Store name is required" }]}
            >
              <Input placeholder="e.g. My E-Commerce App" />
            </Form.Item>

            <Form.Item
              name="storeUrl"
              label="Store URL"
              rules={[
                { required: true, message: "Store URL is required" },
                { type: "url", message: "Enter a valid URL" },
              ]}
            >
              <Input placeholder="https://mystore.com" />
            </Form.Item>

            <Form.Item
              name="storeType"
              label="Platform"
              rules={[{ required: true, message: "Select a platform" }]}
              extra={
                mode === "edit"
                  ? "Platform can't be changed after creation — create a new token if you need a different integration."
                  : undefined
              }
            >
              <Select
                placeholder="Select your e-commerce platform"
                disabled={mode === "edit"}
              >
                {STORE_TYPE_OPTIONS.map((opt) => (
                  <Select.Option
                    key={opt.value}
                    value={opt.value}
                    disabled={opt.disabled}
                  >
                    <div className="flex items-center gap-2">
                      <PlatformIcon type={opt.value} />
                      {opt.disabled ? (
                        <Tooltip title="Coming soon" placement="right">
                          <span className="text-gray-400">{opt.label}</span>
                        </Tooltip>
                      ) : (
                        <span>{opt.label}</span>
                      )}
                    </div>
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item
              noStyle
              shouldUpdate={(prev, next) => prev.storeType !== next.storeType}
            >
              {({ getFieldValue }) => {
                const type = getFieldValue("storeType");
                const isApi = type === "api";
                return (
                  <Form.Item
                    name="scopes"
                    label="Scopes"
                    rules={[
                      { required: true, message: "Select at least one scope" },
                    ]}
                    extra={
                      isApi
                        ? "API tokens always include 'moderate' — that's the scope the async /moderate endpoint checks."
                        : undefined
                    }
                  >
                    <Select
                      mode="multiple"
                      placeholder="Select scopes"
                      options={SCOPE_OPTIONS.map((opt) =>
                        isApi && opt.value === "moderate"
                          ? { ...opt, disabled: true }
                          : opt
                      )}
                    />
                  </Form.Item>
                );
              }}
            </Form.Item>

            <Form.Item
              noStyle
              shouldUpdate={(prev, next) => prev.storeType !== next.storeType}
            >
              {({ getFieldValue }) => {
                const type = getFieldValue("storeType");
                if (type !== "api") return null;
                return (
                  <>
                    <Alert
                      type="info"
                      showIcon
                      className="!mb-3"
                      message="API integration delivers results via webhook"
                      description="We'll POST the AI moderation result (and any metadata you sent) to this URL. No polling, no status calls — your server just receives the verdict."
                    />
                    <Form.Item
                      name="webhookUrl"
                      label="Webhook URL"
                      rules={[
                        {
                          required: true,
                          message: "Webhook URL is required for API tokens",
                        },
                        { type: "url", message: "Enter a valid URL" },
                      ]}
                      tooltip="We POST the moderation result to this endpoint when the worker finishes."
                    >
                      <Input placeholder="https://yourstore.com/webhooks/trust-layer" />
                    </Form.Item>
                  </>
                );
              }}
            </Form.Item>

            <Form.Item
              name="expiresInDays"
              label={
                mode === "edit" ? "Extend expiry by (days)" : "Expires in (days)"
              }
              extra={
                mode === "edit"
                  ? "Leave blank to keep the current expiry. Set a value to push the expiry that many days from now."
                  : undefined
              }
            >
              <InputNumber
                min={1}
                placeholder={
                  mode === "edit"
                    ? "Leave blank to keep current expiry"
                    : "Leave blank for no expiry"
                }
                className="w-full"
              />
            </Form.Item>
          </Form>
        )}
      </Modal>
    </div>
  );
}
