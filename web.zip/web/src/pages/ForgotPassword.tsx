import { Button, Card, Form, Input, Typography, message } from "antd";
import { MailOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";
import { useForgotPasswordMutation } from "../store/authApi";

const AUTH_BG = { background: "linear-gradient(135deg, #f0f4f8 0%, #e8ecf1 50%, #f5f7fa 100%)" };
const AUTH_CARD = { boxShadow: "0 8px 40px rgba(0,0,0,0.06)", border: "1px solid #e5e7eb", borderRadius: 20 };
const LOGO_BLOB = { width: 44, height: 44, background: "rgba(75,106,136,0.1)", borderRadius: "50% 50% 50% 20%", fontSize: 22 };

export default function ForgotPassword() {
  const [forgotPassword, { isLoading, isSuccess }] = useForgotPasswordMutation();

  const onFinish = async (values: { email: string }) => {
    try {
      await forgotPassword(values).unwrap();
      message.success("If the email exists, a reset link has been sent");
    } catch (err: any) {
      message.error(err?.data?.error || "Something went wrong");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={AUTH_BG}>
      <Card className="w-full max-w-md" style={AUTH_CARD} bordered={false}>
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2.5 mb-5">
            <div className="flex items-center justify-center" style={LOGO_BLOB}>🛡️</div>
            <span className="font-extrabold text-xl" style={{ color: "#1b2b3a" }}>Trust Layer</span>
          </div>
          <Typography.Title level={3} className="!mb-1" style={{ fontWeight: 800 }}>Reset password</Typography.Title>
          <Typography.Text type="secondary">Enter your email to receive a reset link</Typography.Text>
        </div>

        {isSuccess ? (
          <div className="text-center py-4">
            <div
              className="mx-auto mb-4 flex items-center justify-center"
              style={{ width: 56, height: 56, borderRadius: "50%", background: "#f0f4f8", fontSize: 28 }}
            >
              ✉️
            </div>
            <Typography.Text className="block mb-4">Check your inbox for a password reset link.</Typography.Text>
            <Link to="/login">
              <Button type="primary" style={{ fontWeight: 600 }}>Back to Login</Button>
            </Link>
          </div>
        ) : (
          <Form layout="vertical" onFinish={onFinish} requiredMark={false} size="large">
            <Form.Item name="email" rules={[{ required: true, message: "Email is required" }, { type: "email", message: "Enter a valid email" }]}>
              <Input prefix={<MailOutlined className="text-gray-400" />} placeholder="Email address" />
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" block size="large" loading={isLoading} style={{ height: 48, fontWeight: 700, fontSize: 15 }}>
                Send Reset Link
              </Button>
            </Form.Item>
            <div className="text-center">
              <Link to="/login"><Typography.Link strong>Back to Login</Typography.Link></Link>
            </div>
          </Form>
        )}
      </Card>
    </div>
  );
}
