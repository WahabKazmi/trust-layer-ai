import { Button, Card, Form, Input, Typography, message } from "antd";
import { LockOutlined } from "@ant-design/icons";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { useResetPasswordMutation } from "../store/authApi";

const AUTH_BG = { background: "linear-gradient(135deg, #f0f4f8 0%, #e8ecf1 50%, #f5f7fa 100%)" };
const AUTH_CARD = { boxShadow: "0 8px 40px rgba(0,0,0,0.06)", border: "1px solid #e5e7eb", borderRadius: 20 };
const LOGO_BLOB = { width: 44, height: 44, background: "rgba(75,106,136,0.1)", borderRadius: "50% 50% 50% 20%", fontSize: 22 };

export default function ResetPassword() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token") || "";
  const [resetPassword, { isLoading }] = useResetPasswordMutation();
  const navigate = useNavigate();

  const onFinish = async (values: { password: string }) => {
    try {
      await resetPassword({ token, password: values.password }).unwrap();
      message.success("Password reset successfully");
      navigate("/login");
    } catch (err: any) {
      message.error(err?.data?.error || "Reset failed");
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4" style={AUTH_BG}>
        <Card className="w-full max-w-md text-center" style={AUTH_CARD} bordered={false}>
          <div className="py-4">
            <Typography.Title level={4} style={{ fontWeight: 800 }}>Invalid Reset Link</Typography.Title>
            <Typography.Text type="secondary">This link is invalid or has expired.</Typography.Text>
            <div className="mt-4">
              <Link to="/forgot-password"><Button type="primary" style={{ fontWeight: 600 }}>Request New Link</Button></Link>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={AUTH_BG}>
      <Card className="w-full max-w-md" style={AUTH_CARD} bordered={false}>
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2.5 mb-5">
            <div className="flex items-center justify-center" style={LOGO_BLOB}>🛡️</div>
            <span className="font-extrabold text-xl" style={{ color: "#1b2b3a" }}>Trust Layer</span>
          </div>
          <Typography.Title level={3} className="!mb-1" style={{ fontWeight: 800 }}>Set new password</Typography.Title>
          <Typography.Text type="secondary">Enter your new password below</Typography.Text>
        </div>

        <Form layout="vertical" onFinish={onFinish} requiredMark={false} size="large">
          <Form.Item name="password" rules={[{ required: true, message: "Password is required" }, { min: 8, message: "At least 8 characters" }]}>
            <Input.Password prefix={<LockOutlined className="text-gray-400" />} placeholder="New password" />
          </Form.Item>
          <Form.Item
            name="confirm"
            dependencies={["password"]}
            rules={[
              { required: true, message: "Confirm your password" },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) return Promise.resolve();
                  return Promise.reject(new Error("Passwords do not match"));
                },
              }),
            ]}
          >
            <Input.Password prefix={<LockOutlined className="text-gray-400" />} placeholder="Confirm password" />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" block size="large" loading={isLoading} style={{ height: 48, fontWeight: 700, fontSize: 15 }}>
              Reset Password
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
}
