import { Card, Typography, Statistic, Row, Col, Tag, Skeleton } from "antd";
import {
  SafetyCertificateOutlined,
  CheckCircleOutlined,
  ShopOutlined,
  ClockCircleOutlined,
} from "@ant-design/icons";
import { useGetMeQuery } from "../store/userApi";
import { useListStoreTokensQuery } from "../store/storeTokenApi";

export default function Dashboard() {
  const { data: user, isLoading: userLoading } = useGetMeQuery();
  const { data: storeTokens, isLoading: tokensLoading } =
    useListStoreTokensQuery();

  const activeTokens =
    storeTokens?.filter((t) => !t.revoked).length ?? 0;
  const revokedTokens =
    storeTokens?.filter((t) => t.revoked).length ?? 0;

  if (userLoading) {
    return <Skeleton active paragraph={{ rows: 6 }} />;
  }

  return (
    <div>
      <div
        className="rounded-2xl p-6 mb-6"
        style={{
          background: "linear-gradient(135deg, #1b2b3a 0%, #2d4256 60%, #3a5570 100%)",
        }}
      >
        <div className="flex items-center gap-4">
          <div
            className="shrink-0 flex items-center justify-center text-white font-extrabold"
            style={{
              width: 56,
              height: 56,
              borderRadius: "50%",
              background: "rgba(255,255,255,0.12)",
              fontSize: 22,
            }}
          >
            {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
          </div>
          <div>
            <Typography.Title level={4} className="!mb-0 !text-white" style={{ fontWeight: 800 }}>
              Welcome back, {user?.name?.split(" ")[0] || "there"}
            </Typography.Title>
            <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 14 }}>
              {user?.email}
            </span>
            <div className="mt-2 flex gap-2">
              <Tag
                style={{
                  background: "rgba(255,255,255,0.12)",
                  border: "none",
                  color: "rgba(255,255,255,0.85)",
                  fontWeight: 600,
                }}
              >
                {user?.role}
              </Tag>
              {user?.emailVerified ? (
                <Tag icon={<CheckCircleOutlined />} color="success">
                  Verified
                </Tag>
              ) : (
                <Tag color="warning">Unverified</Tag>
              )}
            </div>
          </div>
        </div>
      </div>

      <Row gutter={[20, 20]}>
        <Col xs={24} sm={8}>
          <Card loading={tokensLoading} style={{ borderLeft: "3px solid #4B6A88" }}>
            <Statistic
              title="Active Stores"
              value={activeTokens}
              prefix={<ShopOutlined style={{ color: "#4B6A88" }} />}
              valueStyle={{ color: "#1b2b3a", fontWeight: 800 }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={8}>
          <Card loading={tokensLoading} style={{ borderLeft: "3px solid #e5a04b" }}>
            <Statistic
              title="Revoked Tokens"
              value={revokedTokens}
              prefix={<ClockCircleOutlined style={{ color: "#e5a04b" }} />}
              valueStyle={{ color: "#1b2b3a", fontWeight: 800 }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={8}>
          <Card loading={tokensLoading} style={{ borderLeft: "3px solid #7c8db0" }}>
            <Statistic
              title="Total Tokens"
              value={storeTokens?.length ?? 0}
              prefix={<SafetyCertificateOutlined style={{ color: "#7c8db0" }} />}
              valueStyle={{ color: "#1b2b3a", fontWeight: 800 }}
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
}
