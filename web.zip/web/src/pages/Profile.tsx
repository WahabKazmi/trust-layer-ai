import {
  Card,
  Typography,
  Form,
  Input,
  Button,
  Descriptions,
  Divider,
  Popconfirm,
  Tag,
  message,
  Skeleton,
} from "antd";
import { CheckCircleOutlined, WarningOutlined } from "@ant-design/icons";
import { useGetMeQuery, useUpdateMeMutation, useDeleteMeMutation } from "../store/userApi";
import { useAppDispatch } from "../hooks/useAppDispatch";
import { clearTokens } from "../store/authSlice";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

export default function Profile() {
  const { data: user, isLoading } = useGetMeQuery();
  const [updateMe, { isLoading: updating }] = useUpdateMeMutation();
  const [deleteMe, { isLoading: deleting }] = useDeleteMeMutation();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [form] = Form.useForm();

  useEffect(() => {
    if (user) {
      form.setFieldsValue({ name: user.name || "", email: user.email });
    }
  }, [user, form]);

  const onUpdate = async (values: { name: string; email: string }) => {
    try {
      await updateMe(values).unwrap();
      message.success("Profile updated");
    } catch (err: any) {
      message.error(err?.data?.error || "Update failed");
    }
  };

  const onDelete = async () => {
    try {
      await deleteMe().unwrap();
      dispatch(clearTokens());
      message.success("Account deleted");
      navigate("/login");
    } catch (err: any) {
      message.error(err?.data?.error || "Deletion failed");
    }
  };

  if (isLoading) return <Skeleton active paragraph={{ rows: 8 }} />;

  return (
    <div className="w-full mx-auto">
      <Typography.Title level={3} style={{ fontWeight: 800 }}>Profile</Typography.Title>
      <div className="grid grid-cols-2 gap-4">
      <Card className="mb-6">
        <Descriptions column={1} bordered size="small">
          <Descriptions.Item label="ID">
            <span className="font-mono text-xs text-gray-500">{user?.id}</span>
          </Descriptions.Item>
          <Descriptions.Item label="Role">
            <Tag
              style={{
                background: "#eef2f7",
                border: "1px solid #dbe3ed",
                color: "#4B6A88",
                fontWeight: 600,
              }}
            >
              {user?.role}
            </Tag>
          </Descriptions.Item>
          <Descriptions.Item label="Email Verified">
            {user?.emailVerified ? (
              <Tag icon={<CheckCircleOutlined />} color="success">Verified</Tag>
            ) : (
              <Tag icon={<WarningOutlined />} color="warning">Not verified</Tag>
            )}
          </Descriptions.Item>
          <Descriptions.Item label="OAuth Provider">
            {user?.oauthProvider ? (
              <Tag color="purple">{user.oauthProvider}</Tag>
            ) : (
              <span className="text-gray-400">Email / Password</span>
            )}
          </Descriptions.Item>
          <Descriptions.Item label="Joined">
            {user?.createdAt
              ? new Date(user.createdAt).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })
              : "-"}
          </Descriptions.Item>
        </Descriptions>
      </Card>

      <Card
        title={<span className="font-bold">Edit Profile</span>}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={onUpdate}
          requiredMark={false}
        >
          <Form.Item
            name="name"
            label="Name"
            rules={[{ required: true, message: "Name is required" }]}
          >
            <Input size="large" />
          </Form.Item>

          <Form.Item
            name="email"
            label="Email"
            rules={[
              { required: true, message: "Email is required" },
              { type: "email", message: "Enter a valid email" },
            ]}
          >
            <Input size="large" />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" loading={updating} style={{ fontWeight: 600 }}>
              Save Changes
            </Button>
          </Form.Item>
        </Form>
      </Card>
      </div>

      <Divider />

      <Card
        title={<span className="font-bold text-red-600">Danger Zone</span>}
        style={{ border: "1px solid #fecaca" }}
      >
        <Typography.Text type="secondary">
          Once you delete your account, all data will be permanently removed.
          This action cannot be undone.
        </Typography.Text>
        <div className="mt-4">
          <Popconfirm
            title="Delete your account?"
            description="This action is permanent and cannot be undone."
            onConfirm={onDelete}
            okText="Yes, delete"
            okButtonProps={{ danger: true }}
          >
            <Button danger loading={deleting}>
              Delete Account
            </Button>
          </Popconfirm>
        </div>
      </Card>
    </div>
  );
}
