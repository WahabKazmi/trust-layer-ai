import { Button, Card, Form, Input, Typography, Divider, message } from "antd";
import {
  MailOutlined,
  LockOutlined,
  GoogleOutlined,
  GithubOutlined,
} from "@ant-design/icons";
import { Link, useNavigate } from "react-router-dom";
import { useLoginMutation } from "../store/authApi";
import { useAppDispatch } from "../hooks/useAppDispatch";
import { setTokens } from "../store/authSlice";

const AUTH_BG = { background: "linear-gradient(135deg, #f0f4f8 0%, #e8ecf1 50%, #f5f7fa 100%)" };
const AUTH_CARD = { boxShadow: "0 8px 40px rgba(0,0,0,0.06)", border: "1px solid #e5e7eb", borderRadius: 20 };
const LOGO_BLOB = { width: 44, height: 44, background: "rgba(75,106,136,0.1)", borderRadius: "50% 50% 50% 20%", fontSize: 22 };

export default function Login() {
  const [login, { isLoading }] = useLoginMutation();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const onFinish = async (values: { email: string; password: string }) => {
    try {
      const res = await login(values).unwrap();
      dispatch(setTokens(res));
      message.success("Logged in successfully");
      navigate("/dashboard");
    } catch (err: any) {
      message.error(err?.data?.error || "Login failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={AUTH_BG}>
      <Card className="w-full max-w-md" style={AUTH_CARD} bordered={false}>
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2.5 mb-5">
            <div className="flex items-center justify-center" style={LOGO_BLOB}>🛡️</div>
            <span className="font-extrabold text-xl" style={{ color: "#1b2b3a" }}>Trust Layer</span>
          </div>
          <Typography.Title level={3} className="!mb-1" style={{ fontWeight: 800 }}>
            Welcome back
          </Typography.Title>
          <Typography.Text type="secondary">Sign in to your dashboard</Typography.Text>
        </div>

        <Form layout="vertical" onFinish={onFinish} requiredMark={false} size="large">
          <Form.Item name="email" rules={[{ required: true, message: "Email is required" }, { type: "email", message: "Enter a valid email" }]}>
            <Input prefix={<MailOutlined className="text-gray-400" />} placeholder="Email address" />
          </Form.Item>
          <Form.Item name="password" rules={[{ required: true, message: "Password is required" }]}>
            <Input.Password prefix={<LockOutlined className="text-gray-400" />} placeholder="Password" />
          </Form.Item>
          <div className="flex justify-end mb-4 -mt-2">
            <Link to="/forgot-password"><Typography.Link>Forgot password?</Typography.Link></Link>
          </div>
          <Form.Item>
            <Button type="primary" htmlType="submit" block size="large" loading={isLoading} style={{ height: 48, fontWeight: 700, fontSize: 15 }}>
              Sign In
            </Button>
          </Form.Item>
        </Form>

        <Divider plain className="!text-gray-400 !text-xs">or continue with</Divider>
        <div className="flex gap-3">
          <Button icon={<GoogleOutlined />} block size="large" href="/api/auth/google" style={{ fontWeight: 600 }}>Google</Button>
          <Button icon={<GithubOutlined />} block size="large" href="/api/auth/github" style={{ fontWeight: 600 }}>GitHub</Button>
        </div>
        <div className="text-center mt-6">
          <Typography.Text type="secondary">
            Don't have an account?{" "}
            <Link to="/register"><Typography.Link strong>Sign up</Typography.Link></Link>
          </Typography.Text>
        </div>
      </Card>
    </div>
  );
}
