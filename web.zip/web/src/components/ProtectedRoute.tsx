import { Navigate, Outlet } from "react-router-dom";
import { useAppSelector } from "../hooks/useAppDispatch";

export default function ProtectedRoute() {
  const token = useAppSelector((s) => s.auth.accessToken);

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
}
