import { useState } from "react";
import { Layout, Menu, Dropdown, Avatar, Button, message } from "antd";
import {
  DashboardOutlined,
  UserOutlined,
  SafetyCertificateOutlined,
  TeamOutlined,
  LogoutOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
} from "@ant-design/icons";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { useGetMeQuery } from "../store/userApi";
import { useLogoutMutation } from "../store/authApi";
import { useAppDispatch, useAppSelector } from "../hooks/useAppDispatch";
import { clearTokens } from "../store/authSlice";

const { Sider, Header, Content } = Layout;

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { data: user } = useGetMeQuery();
  const [logout] = useLogoutMutation();
  const dispatch = useAppDispatch();
  const refreshToken = useAppSelector((s) => s.auth.refreshToken);

  const handleLogout = async () => {
    try {
      if (refreshToken) await logout({ refreshToken }).unwrap();
    } catch {
      // proceed anyway
    }
    dispatch(clearTokens());
    message.success("Logged out");
    navigate("/login");
  };

  const menuItems = [
    {
      key: "/dashboard",
      icon: <DashboardOutlined />,
      label: "Dashboard",
    },
    {
      key: "/profile",
      icon: <UserOutlined />,
      label: "Profile",
    },
    {
      key: "/store-tokens",
      icon: <SafetyCertificateOutlined />,
      label: "Store Tokens",
    },
    ...(user?.role === "ADMIN"
      ? [
          {
            key: "/admin/users",
            icon: <TeamOutlined />,
            label: "Users",
          },
        ]
      : []),
  ];

  const avatarMenu = {
    items: [
      {
        key: "profile",
        icon: <UserOutlined />,
        label: "Profile",
        onClick: () => navigate("/profile"),
      },
      { type: "divider" as const },
      {
        key: "logout",
        icon: <LogoutOutlined />,
        label: "Logout",
        danger: true,
        onClick: handleLogout,
      },
    ],
  };

  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "U";

  return (
    <Layout className="min-h-screen">
      <Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        breakpoint="lg"
        onBreakpoint={(broken) => setCollapsed(broken)}
        width={240}
        style={{
          background: "linear-gradient(180deg, #1b2b3a 0%, #243447 100%)",
        }}
      >
        <div
          className="flex items-center gap-2.5 px-5 py-4"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
        >
          <div
            className="flex items-center justify-center shrink-0"
            style={{
              width: 36,
              height: 36,
              background: "rgba(255,255,255,0.1)",
              borderRadius: "50% 50% 50% 20%",
              fontSize: 18,
            }}
          >
            🛡️
          </div>
          {!collapsed && (
            <span
              className="text-white font-extrabold tracking-tight"
              style={{ fontSize: 18 }}
            >
              Trust Layer
            </span>
          )}
        </div>
        <Menu
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={({ key }) => navigate(key)}
          style={{ background: "transparent", border: "none", marginTop: 8 }}
        />
      </Sider>

      <Layout>
        <Header
          className="flex items-center justify-between"
          style={{
            background: "#fff",
            padding: "0 24px",
            borderBottom: "1px solid #e5e7eb",
            height: 64,
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{ color: "#374151" }}
          />
          <Dropdown menu={avatarMenu} placement="bottomRight" trigger={["click"]}>
            <div className="flex items-center gap-2.5 cursor-pointer">
              <span className="hidden sm:inline text-sm font-semibold text-gray-700">
                {user?.name || user?.email || "User"}
              </span>
              <Avatar
                style={{
                  background: "#4B6A88",
                  fontWeight: 700,
                  fontSize: 13,
                }}
                size={36}
              >
                {initials}
              </Avatar>
            </div>
          </Dropdown>
        </Header>

        <Content style={{ padding: 24, minHeight: "calc(100vh - 64px)" }}>
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
}
